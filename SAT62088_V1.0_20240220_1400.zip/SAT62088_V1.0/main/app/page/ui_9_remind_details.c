﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE9 // 当前页面的ID序号
#define G_STR_BUF_REMIND    g_strBuffer1
static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE9_OBJ_IMG_BG = 0,

    PAGE9_OBJ_LABEL_REMIND,
}SCREEN_PAGE9_OBJ;

//单独控件
/***************************************************/

/***************************************************/
//接口定义
/***************************************************/
 

/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, 0,0,&alpha_bg_grey, EXP_IMG_DEFT},
    
    {QTYPE_TXT, 0,90, G_STR_BUF_REMIND, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold34}}},
    EXP_OBJ_END };


 

void page_init_set_wifi_app(void)
{
    //obj show hid
    
    //set label and img
    sprintf(G_STR_BUF_REMIND,"Open\nMSmartLife app");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 90);
}

void page_init_set_wifi_connecting(void)
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"Connecting");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 110);
}

void page_init_set_wifi_complete(void)
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"Complete!");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 110);
}

void page_init_set_version(void)
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"xxxx\nxxxxx");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 90);
}

void page_init_set_wifi_reset(void) 
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"Resetting");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 110);
}

void page_init_set_wifi_reset_complete(void)
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"Reseted");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 110);
}

void page_init_set_wifi_connect_fail(void)
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"Failed to\nconnect to WIFI");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 90);
}

void page_init_set_wifi_reset_fail(void)
{
    //obj show hid

    //set label and img
    sprintf(G_STR_BUF_REMIND,"Failed to\nconnect to WIFI");
    //to do
    lqui.set_pos(PAGE9_OBJ_LABEL_REMIND, 0, 90);
}

static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);

    ui_page_switch();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}

//////////////////////////////////////////////////////////////////////////


void screen_page9_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
