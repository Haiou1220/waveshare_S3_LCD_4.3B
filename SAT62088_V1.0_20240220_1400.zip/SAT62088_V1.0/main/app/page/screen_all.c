﻿#include "screen_all.h"
#include <stdlib.h> //add for vc:malloc
#include "../lqui/lqui_helper.h"
#include "../page/global_value.h"
#include "../bps_driver/mcu_platform.h"

QuiPage* g_all_screenObj;

RunStateStruct RunningState;
static bool g_factory_flag = 0;

SensorReheatStruct sr_table[SRID_MAX] = {
    {SRID_0,"none","none","none","none",0},
    {SRID_Potato,"Potato","Roasting Pan","Middle","6min",0},
};

AutoMenuStruct am_table[AMID_MAX] = {
    {AMID_0,"none","none","none","none","none",0},
};


const char* g_scr_tag[] =
{
    "FCT_MODE",
    "QSTART",
    "MAIN",
    "SETTING",
    "BEANS_POWDER",
    "SIGNAL_TONES",
    "WATER_FILTER",
    "WATER_HARDNESS",
    "TIME",
    "MANUAL",
    "LANGUAGE",
    "EXPERT",
    "RESET",
    "COFFEE_PROCESS",
    "CLEANING",
    "ALARM",
    "ALARM_TIME",
    "ALARM_PROCESS",
    "ERR_CODE",
};

bool get_g_factory_flag(void)
{
    return g_factory_flag;
}

static void timer_thread(void *arg)
{
    extern void Sleep(int ms);
    uint32_t flag_timestamp=0;
    uint32_t curr_timestamp = 0;
    while (1)
    {
        Sleep(100);
        curr_timestamp = GetTickCount() / 1000;
        if (flag_timestamp != curr_timestamp)
        {
            flag_timestamp = curr_timestamp;
            
            if (++g_main_sec > 59)
            {
                g_main_sec = 0;
                if (++g_main_min > 59)
                {
                    g_main_min = 0;
                    g_main_hour = (g_main_hour + 1) % 24;;
                }
            }
        }
    }
}

static void page_init_no(void)
{

}

extern uint8_t g_page_id;

void ui_page_switch(void)
{
    const uint8_t page_index_table[IdMax][2] = {
        {IdMainLock, PAGE1},
        {IdMain, PAGE1},
        {IdSleep, PAGE1},
        {IdMicroPowerSet, PAGE3},
        {IdMicroTimeSet, PAGE4},
        {IdMicroCooking,PAGE5},
        {IdMicroPause,PAGE5},
        {IdMicroComplete,PAGE6},
        {IdAirfryTempSet, PAGE3},
        {IdAirfryTimeSet, PAGE4},
        {IdAirfryCooking,PAGE5},
        {IdAirfryPause,PAGE5},
        {IdAirfryComplete,PAGE6},
        {IdConvbakeTempSet, PAGE3},
        {IdConvbakeTimeSet,PAGE4},
        {IdConvbakeCooking,PAGE5},
        {IdConvbakePerheat,PAGE10},
        {IdConvbakePause,PAGE5},
        {IdConvbakeComplete,PAGE6},
        {IdMenu,PAGE14}, 
        {IdMenuWeight,PAGE15},
        {IdMenuPerheat,PAGE1}, //page no 
        {IdMenuPerheatPause,PAGE1}, //page no 
        {IdMenuCooking,PAGE5}, 
        {IdMenuCookingPause,PAGE5}, 
        {IdMenuCookingComplete,PAGE6},
        {IdCookingPerheatComplete,PAGE1}, //page no 
        {IdSetSound,PAGE7},
        {IdSetLock,PAGE7},
        {IdSetClock,PAGE7},
        {IdSetWifi,PAGE7},
        {IdSetAbout,PAGE7},
        {IdOldMode,PAGE1}, //page no 
        {IdSetSoundClose,PAGE8},
        {IdSetSoundOn,PAGE8},
        {IdSetLockClose,PAGE8},
        {IdSetLockOn,PAGE8},
        {IdSetLockRemind,PAGE1},
        {IdSetUnlock,PAGE1},
        {IdSetClockAdjust,PAGE8},
        {IdSetWifiWaitingConnect,PAGE8},
        {IdSetWifiApp,PAGE9},
        {IdSetWifiConnecting,PAGE9},
        {IdSetWifiComplete,PAGE9},
        {IdSetWifiConnectFail,PAGE9},
        {IdSetWifiWaitingReset,PAGE8},
        {IdSetWifiReset,PAGE9},
        {IdSetWifiResetComplete,PAGE9},
        {IdSetWifiResetFail,PAGE9},
        {IdSetVersion,PAGE9},
        {IdDefrostTimerSet,PAGE4},
        {IdDefrostWorking,PAGE5},
        {IdDefrostPause,PAGE5},
        {IdDefrostComplete,PAGE6},
        {IdConvbakePerheatComplete,PAGE10},
        {IdBroilTimeSet,PAGE4},
        {IdBroilCooking,PAGE5},
        {IdBroilPause,PAGE5},
        {IdBroilComplete,PAGE6},
        {IdMenuDetails,PAGE13},
        {IdCombiTimeSet,PAGE4},
        {IdCombiWorking,PAGE5},
        {IdCombiPause,PAGE5},
        {IdCombiComplete,PAGE6},
        {IdTimerTimeSet,PAGE4},
        {IdTimerWorking,PAGE5},
        {IdTimerPause,PAGE5},
        {IdTimerComplete,PAGE6},
        {IdSensorReheatAddFood,PAGE11},
        {IdSensorReheatFoodRecognizing,PAGE12},
        {IdSensorReheatCooking,PAGE5},
        {IdSensorReheatPause,PAGE5},
        {IdSensorReheatComplete,PAGE6},
        {IdMainLockOnRemind,PAGE1},
        {IdFct,PAGE0},
    };

    const void(*page_init_table[IdMax])(void) = {
        page_init_main_lock,
        page_init_main,
        page_init_sleep,
        page_init_micro_power_set,
        page_init_micro_time_set,
        page_init_micro_cooking,//5
        page_init_micro_pause,
        page_init_micro_complete,
        page_init_air_fry_temp_set,
        page_init_air_fry_time_set,
        page_init_air_fry_cooking,//10
        page_init_air_fry_pause,
        page_init_air_fry_complete,
        page_init_conv_bake_temp_set,
        page_init_conv_bake_time_set,
        page_init_conv_bake_cooking,//15
        page_init_conv_bake_perheat,
        page_init_conv_bake_pause,
        page_init_conv_bake_complete,
        page_init_menu, 
        page_init_menu_weight,
        page_init_sleep,//page no
        page_init_sleep,//page no
        page_init_menu_cooking,
        page_init_menu_cooking_pause,
        page_init_menu_cooking_complete,
        page_init_sleep,//page no
        page_init_set_sound,
        page_init_set_lock,
        page_init_set_clock,
        page_init_set_wifi,//30
        page_init_set_about,
        page_init_sleep,//page no
        page_init_set_sound_close,
        page_init_set_sound_on,
        page_init_set_lock_close,//35
        page_init_set_lock_on,
        page_init_set_lock_remind,
        page_init_set_unlock,
        page_init_set_clock_adjust,
        page_init_set_wifi_waiting_connect,//40
        page_init_set_wifi_app,
        page_init_set_wifi_connecting,
        page_init_set_wifi_complete,
        page_init_set_wifi_connect_fail,
        page_init_set_wifi_waiting_reset,//45
        page_init_set_wifi_reset,
        page_init_set_wifi_reset_complete,
        page_init_set_wifi_reset_fail,
        page_init_set_version,
        page_init_defrost_time_set,//50
        page_init_defrost_working,
        page_init_defrost_pause,
        page_init_defrost_complete,
        page_init_conv_bake_perheat_complete,
        page_init_broil_time_set,//55
        page_init_broil_cooking,
        page_init_broil_pause,
        page_init_broil_complete,
        page_init_menu_details,
        page_init_combi_time_set,//60
        page_init_combi_working,
        page_init_combi_pause,
        page_init_combi_complete,
        page_init_timer_time_set,
        page_init_timer_working,//65
        page_init_timer_pause,
        page_init_timer_complete,

        page_init_sensor_reheat_add_food,
        page_init_sensor_reheat_food_recognizing,
        page_init_SensorReheatCooking,
        page_init_SensorReheatPause,
        page_init_sensor_reheat_complete,
        page_init_main_lock_on_remind,
        page_init_fct,
    };

    static int page_id_old = -1;
    static bool ready_switch_flag = 0;
    static bool running_flag = 0;

    running_flag = 1;

    if (page_id_old != RunningState.pageid)
    {
        if(RunningState.pageid < IdMax)
        {
            page_id_old = RunningState.pageid;

            ready_switch_flag = 1;
            running_flag = 0;

            if(g_page_id != page_index_table[page_id_old][1])
            {
                lqui.switch_page(page_index_table[page_id_old][1]);//switch to PAGE
                g_page_id = page_index_table[page_id_old][1];
            }

            if(page_id_old == IdFct)
                g_factory_flag = 1;
            else 
                g_factory_flag = 0;
        }
    }

    if((ready_switch_flag)&&(running_flag))//wait page switch and init all success,than to init id page
    {
        page_init_table[page_id_old]();//init page
        ready_switch_flag = 0;
    }

}


void screen_all_init()
{
    lqui_helper_init();
    screen_tool_init();
    g_all_screenObj = (QuiPage*)malloc(MAX_SCREEN_ID * sizeof(QuiPage));
    println("g_all_screenObj,max_id=%d,address=%p \n", MAX_SCREEN_ID, &g_all_screenObj);
    println("LV_COLOR_DEPTH=%d,LV_COLOR_16_SWAP=%d.", LV_COLOR_DEPTH, LV_COLOR_16_SWAP);
    
    //各页面的布局初始化
    screen_page0_init();
    screen_page1_init();
    screen_page3_init();
    screen_page4_init();
    screen_page5_init();
    screen_page6_init();
    screen_page7_init();
    screen_page8_init();
    screen_page9_init();
    screen_page10_init();
    screen_page11_init();
    screen_page12_init();
    screen_page13_init();
    screen_page14_init();
    screen_page15_init();
    printf("%s\n",MY_VERSION);

    #if SYSTEM_DEBUG
    RunningState.pageid = IdMax-1;//goto main
    #else
    RunningState.pageid = IdMain;//goto main
    #endif
    

    int nErrCnt = 0;
    for (int i = 0; i < MAX_SCREEN_ID; i++)
    {
        if (g_all_screenObj[i].page_objs == NULL)
        {
            println("\x1b[0;31m***Error*** screen init missing[%d].\n\x1b[0m", i);
            nErrCnt++;
        }
    }
    if (nErrCnt == 0)
    {
        println("screen init sucess! num=%d.\n", MAX_SCREEN_ID);
    }
    else
    {
        // exit(0);
    }

    start_thread(timer_thread, 1024 * 5, 1);

}
