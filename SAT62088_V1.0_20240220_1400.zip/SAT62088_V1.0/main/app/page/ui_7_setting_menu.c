﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE7 // 当前页面的ID序号
#define G_STR_BUF_TITLE1    g_strBuffer1
#define G_STR_BUF_TITLE2    g_strBuffer2
#define G_STR_BUF_TITLE3    g_strBuffer3
#define G_STR_BUF_MIDDLE    g_strBuffer4

static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE7_OBJ_IMG_TOP = 0,
    PAGE7_OBJ_IMG_WIFI,
    PAGE7_OBJ_IMG_MIDDLE,

    PAGE7_OBJ_LABEL_TITLE1,
    PAGE7_OBJ_LABEL_TITLE2,
    PAGE7_OBJ_LABEL_TITLE3,
    PAGE7_OBJ_LABEL_MIDDLE,
}SCREEN_PAGE7_OBJ;

//接口定义
/***************************************************/

/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    {QTYPE_IMG, 0,0,&alpha_sound_on, EXP_IMG_DEFT},

    {QTYPE_TXT, -109, TITLE_LABEL_Y, G_STR_BUF_TITLE1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 53, 13, G_STR_BUF_TITLE2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold25}}},
    {QTYPE_TXT, 85, 14, G_STR_BUF_TITLE3, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0x7D7C7A,& myriadpro_regular25}}},
    {QTYPE_TXT, 0, 160, G_STR_BUF_MIDDLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold40}}},
    EXP_OBJ_END };

static void wifi_auto_show(void)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (RunningState.wifi_state)
    {
        case 0: //disconnect
            lqui.show_obj(1, 0);
            break;
        case 1: //connecting
            if (secold != g_main_sec)
            {
                secold = g_main_sec;
                twink_flag = !twink_flag;
                lqui.show_obj(PAGE7_OBJ_IMG_WIFI, twink_flag);
            }
            break;
        case 2: //complete
            lqui.show_obj(PAGE7_OBJ_IMG_WIFI, TRUE);
            break;
    }
}

void page_init_set_sound(void)
{
    //show and hid

    //set label and img
    lqui.set_img_src(PAGE7_OBJ_IMG_MIDDLE, &alpha_sound_on);
    sprintf(G_STR_BUF_TITLE1,"Settings");
    sprintf(G_STR_BUF_TITLE2,"01");
    sprintf(G_STR_BUF_TITLE3,"/05");
    sprintf(G_STR_BUF_MIDDLE,"Sound");
    //to do
}

void page_init_set_lock(void)
{
    //show and hid

    //set label and img
    lqui.set_img_src(PAGE7_OBJ_IMG_MIDDLE, &alpha_lock_on);
    sprintf(G_STR_BUF_TITLE1,"Settings");
    sprintf(G_STR_BUF_TITLE2,"02");
    sprintf(G_STR_BUF_TITLE3,"/05");
    sprintf(G_STR_BUF_MIDDLE,"Child Lock");
    //to do
}

void page_init_set_clock(void)
{
    //show and hid

    //set label and img
    lqui.set_img_src(PAGE7_OBJ_IMG_MIDDLE, &alpha_clock);
    sprintf(G_STR_BUF_TITLE1,"Settings");
    sprintf(G_STR_BUF_TITLE2,"03");
    sprintf(G_STR_BUF_TITLE3,"/05");
    sprintf(G_STR_BUF_MIDDLE,"Clock");
    //to do
}

void page_init_set_wifi(void)
{
    //show and hid

    //set label and img
    lqui.set_img_src(PAGE7_OBJ_IMG_MIDDLE, &alpha_wifi_connect);
    sprintf(G_STR_BUF_TITLE1,"Settings");
    sprintf(G_STR_BUF_TITLE2,"04");
    sprintf(G_STR_BUF_TITLE3,"/05");
    sprintf(G_STR_BUF_MIDDLE,"Connect");
    //to do
}

void page_init_set_about(void)
{
    //show and hid

    //set label and img
    lqui.set_img_src(PAGE7_OBJ_IMG_MIDDLE, &alpha_about);
    sprintf(G_STR_BUF_TITLE1,"Settings");
    sprintf(G_STR_BUF_TITLE2,"05");
    sprintf(G_STR_BUF_TITLE3,"/05");
    sprintf(G_STR_BUF_MIDDLE,"About");
    //to do
}

 


static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);
    static uint32_t flag_timesec = 0;
    ui_page_switch();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}


void screen_page7_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
