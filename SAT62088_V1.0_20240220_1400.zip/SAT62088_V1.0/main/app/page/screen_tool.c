﻿#include <stdio.h>
#include "lvgl.h"
#include "app/lqui/lqui_base.h"
#include "app/bps_driver/pc_platform.h"

#ifdef _WIN32
#include <stdlib.h> //add for vc:malloc
#include <Windows.h>
#endif // _WIN32



//**********  declear function *****************
 
//***********************************************
typedef struct TalineObj
{
    lv_obj_t* obj;
    lv_point_t point[2];
    uint8_t max_len;
} LineObject;

static LineObject* g_lineObj = NULL;
static int g_mouseX = 0;
static int g_mouseY = 0;
static int g_clickType = 0;
static bool g_enable_adjust = false;
static uint8_t g_bCtrl = 0;//上升沿
static uint8_t g_bTab = 0;
static uint8_t g_bEsc = 0;
static uint8_t g_nCtrl = 0;//电平值
static uint8_t g_nTab = 0;
static uint8_t g_nEsc = 0;
lv_obj_t* g_top_log_obj = NULL;
char g_top_log_str[512] = { 0 };
int  g_top_log_cnt = 0;
int (*gFunc_GetMousePos)(int* x, int* y);

void get_mouse_pos(int* x, int* y)
{
    *x = g_mouseX;
    *y = g_mouseY;
}

LineObject* screen_init_lines(lv_obj_t* parent, uint8_t lineNums, uint8_t lineWidth, uint32_t lineColor)
{

    LineObject* lineObj = (LineObject*)malloc(sizeof(LineObject) * lineNums);

    if (lineObj == NULL)
    {
        printf("Error,lineObj is null!\n");
        return NULL;
    }

    for (size_t i = 0; i < lineNums; i++)
    {
        lineObj[i].max_len = lineNums;
        lineObj[i].obj = lv_line_create(parent);

        lv_obj_set_style_line_color(lineObj[i].obj, lv_color_hex(lineColor), 0); // 设置直线样式颜色
        lv_obj_set_style_line_width(lineObj[i].obj, lineWidth, 0);               // 设置直线样式宽度
        lv_obj_set_style_line_rounded(lineObj[i].obj, true, 0);                  // 设置直线样式圆形的(末端)

        lineObj[i].point[0].x = 0;
        lineObj[i].point[0].y = 0;

        lineObj[i].point[1].x = 0;
        lineObj[i].point[1].y = 0;

        lv_line_set_points(lineObj[i].obj, lineObj[i].point, 2);
    }
    printf("line num=%d,px=%d,init finish.\n", lineNums, lineWidth);

    return lineObj;
}

void screen_show_line(LineObject* lineObj, bool bShow)
{
    void (*fun)(lv_obj_t*, lv_obj_flag_t*);
    if (bShow)
        fun = &lv_obj_clear_flag;
    else
        fun = &lv_obj_add_flag;

    int len = lineObj[0].max_len;

    for (size_t i = 0; i < len; i++)
    {
        fun(lineObj[i].obj, LV_OBJ_FLAG_HIDDEN);
    }
}

void screen_draw_line(LineObject* lineObj, int line_id, int x0, int y0, int x1, int y1)
{

    if (lineObj[line_id].max_len > line_id)
    {
        lineObj[line_id].point[0].x = x0;
        lineObj[line_id].point[0].y = y0;
        lineObj[line_id].point[1].x = x1;
        lineObj[line_id].point[1].y = y1;
        lv_line_set_points(lineObj[line_id].obj, lineObj[line_id].point, 2);
    }
}

static void screen_draw_frame(LineObject* lineObj, QuiObj obj)
{
    int offset = 5; // 预留缝隙
    // long ten
    screen_draw_line(lineObj, 0, 0, obj.y, obj.x - offset, obj.y);
    screen_draw_line(lineObj, 1, obj.x + offset, obj.y, CANVAS_WIDTH, obj.y);

    screen_draw_line(lineObj, 2, obj.x, 0, obj.x, obj.y - offset);
    screen_draw_line(lineObj, 3, obj.x, obj.y + offset, obj.x, CANVAS_HEIGHT);
}

void screen_adjust_auto(QuiObj* quiObj, int len,char* infoStr)
{
#if(_WIN32==1)

    static int index = -1;
    static bool flag_ctrl = false;
    QuiObj* obj = quiObj;
    if (len < 1)
        return;
    if (g_bTab)
    {
        if (!g_enable_adjust)
        {
            screen_show_line(g_lineObj, true);
        }
        index = (index + 1) % len;
        printf("tab index=%d.pos=(%d,%d)\n", index, (obj+index)->x, (obj + index)->y);
        g_bTab = 0;
        g_enable_adjust = true;
    }

    if (g_nEsc)
    {
        g_nEsc = 0;
            printf("PageInfo:[%s],object count=%d.\n",infoStr,len);
            printf("============================================\n");
            for (size_t i = 0; i < len; i++)
            {
                printf("QuiObj[%d], x = %3d, y = %3d,flag = %04x \n", i, obj->x, obj->y, obj->layoutParam.qui_flag);
                obj++;
            }
            printf("============================================\n");
            index = -1;
            g_enable_adjust = false;
            screen_show_line(g_lineObj, false);

    }


    if (!g_enable_adjust)
    {
        return;
    }

    obj += index;
    if (g_nCtrl)
    {
        gFunc_GetMousePos(&g_mouseX,&g_mouseY);//mouseXY in windows
        obj->x = g_mouseX;
        obj->y = g_mouseY;
    }
    screen_draw_frame(g_lineObj, *obj);
#endif
}

void screen_free_lines(LineObject** lineObj)
{
    if (lineObj)
    {
        int len = lineObj[0]->max_len;
        for (size_t i = 0; i < len; i++)
        {
            if (lineObj[i])
            {
                free(lineObj[i]);
                lineObj[i] = NULL;
            }
        }
    }
}

int screen_monitor_thread(void* arg)
{
#ifdef _WIN32
    uint8_t flag_up[3] = { 0 };
    uint8_t vk_table[3] = { VK_TAB, VK_CONTROL,VK_ESCAPE };
    uint8_t* key_rise[3] = { &g_bTab,&g_bCtrl,&g_bEsc };//上升沿
    uint8_t* key_value[3] = {&g_nTab,&g_nCtrl,&g_nEsc};//电平值

    while (true) // 建立事件主循环
    {
        Sleep(50);
        for (size_t i = 0; i < 3; i++)
        {
            if ((GetKeyState(vk_table[i]) & 0x8000))
            {
                *key_value[i] = 1;
                if (flag_up[i])
                {
                    flag_up[i] = 0;
                    *key_rise[i] = 1;
                }
            }
            else
            {
                *key_value[i] = 0;
                flag_up[i] = 1;
            }
        }
    }
#endif
    printf("quit screen_monitor_thread.! \n");
    return 0;
}


void screen_tool_init()
{
    printf("call screen_tool_init().\n");

#if (_WIN32==1)
    // after lvgl init
    g_lineObj = screen_init_lines(lv_layer_sys(), 4, 2, 0xff80ff);
    //pthread_t thread_scr;
    //pthread_create(&thread_scr, NULL, screen_monitor_thread, NULL);
    start_thread(screen_monitor_thread, 1024 * 5, 1);
    g_top_log_obj = lv_label_create(lv_layer_top());
    lv_label_set_text(g_top_log_obj, "");
#endif

    



}
