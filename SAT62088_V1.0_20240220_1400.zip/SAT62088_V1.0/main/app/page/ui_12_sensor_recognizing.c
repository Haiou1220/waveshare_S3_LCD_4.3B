﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE12 // 当前页面的ID序号
static int g_obj_cnt = 0; // 当前页面的控件数量

#define G_STR_BUF_TITLE        g_strBuffer1
#define G_STR_BUF_MIDDLE       g_strBuffer2

typedef enum {
    PAGE12_OBJ_IMG_TITLE_WIFI,
    PAGE12_OBJ_IMG_BG,

    PAGE12_OBJ_LABEL_TITLE,
    PAGE12_OBJ_LABEL_MIDDLE,
}SCREEN_PAGE12_OBJ;


//单独控件
/***************************************************/

/***************************************************/
//接口定义
/***************************************************/
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    {QTYPE_IMG, 0,0,&alpha_scan_box, EXP_IMG_DEFT},
    
    {QTYPE_TXT, -70, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 0, 80, G_STR_BUF_MIDDLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold40}}},
    EXP_OBJ_END };


static void wifi_auto_show(void)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (RunningState.wifi_state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE12_OBJ_IMG_TITLE_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE12_OBJ_IMG_TITLE_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE12_OBJ_IMG_TITLE_WIFI, TRUE);
        break;
    }
}

void page_init_sensor_reheat_food_recognizing(void)
{
    //show and hid

    //set label and img
    sprintf(G_STR_BUF_TITLE,"Sensor Reheat");
    sprintf(G_STR_BUF_MIDDLE,"Food\nRecognizing");
    //to do
}


static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);

    ui_page_switch();
    wifi_auto_show();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}

//////////////////////////////////////////////////////////////////////////


void screen_page12_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
