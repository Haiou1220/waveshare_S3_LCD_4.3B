﻿
#include <stdio.h>
#include "screen_all.h"

#include "../control/ctrl_main.h"
#include "../lqui/lqui_helper.h"

#include "global_value.h"
#include "esp_log.h"
#include "../../driver_protocol.h"

#define CUR_SCREEN_ID   PAGE0   // 当前页面的ID序号
static int g_obj_cnt = 0; // 当前页面的控件数量
static lv_obj_t* g_page_parent = NULL;
static uint32_t g_fct_tick = 0;



// QuiObj结构体： 类型, 坐标(x,y), 数据指针, 参数结构体指针
static QuiObj g_objs[] = {
    {QTYPE_TXT, 0, 10, "FCT Mode", { LQ_OBJ_FLAG_CENTER, NULL, &(QuiTxtParam) { QUI_WHITE, &myriadpro_regular25 }} },
    {QTYPE_TXT, 0, 60, MY_VERSION, { LQ_OBJ_FLAG_CENTER, NULL, &(QuiTxtParam) { QUI_WHITE, &myriadpro_regular25 }} },
    {QTYPE_TXT, 0, 100, g_strBuffer1, { LQ_OBJ_FLAG_CENTER, NULL, &(QuiTxtParam) { QUI_WHITE, &myriadpro_regular25 }} },
    {QTYPE_LNE, 0, 0,  &(lv_point_t[2]){ {0, 0}, {0, CANVAS_HEIGHT}}, {0x00,NULL,&(QuiLneParam){2,0xFF0000}}},//[4]
    {QTYPE_LNE, 0, 0,  &(lv_point_t[2]){ {0, 0}, {CANVAS_WIDTH, 0}}, {0x00,NULL,&(QuiLneParam){2,0xFF0000}}},
    {QTYPE_LNE, 0, 0,  &(lv_point_t[2]){ {0, CANVAS_HEIGHT}, {CANVAS_WIDTH, CANVAS_HEIGHT}}, {0x00,NULL,&(QuiLneParam){2,0xFF0000}}},
    {QTYPE_LNE, 0, 0,  &(lv_point_t[2]){ {CANVAS_WIDTH, CANVAS_HEIGHT}, {CANVAS_WIDTH, 0}}, {0x00,NULL,&(QuiLneParam){2,0xFF0000}}},

    EXP_OBJ_END };

static uint32_t itpGetTickDuration(uint32_t timer) // 获取与当前时间戳的差值
{
    uint32_t Temp_Time_Count = 0;
    // calculate how many time one time in system main loop
    if (esp_log_timestamp() != timer)
    {
        if (esp_log_timestamp() >= timer)
        {
            Temp_Time_Count = (uint32_t)(esp_log_timestamp() - timer);
        }
        else
        {
            Temp_Time_Count = (uint32_t)(0xFFFFFFFF - timer + esp_log_timestamp());
        }
    }
    return Temp_Time_Count;
}


void set_gnd_color(uint32_t color)
{
    lv_obj_set_style_bg_color(g_page_parent, lv_color_hex(color), LV_PART_MAIN | LV_STATE_DEFAULT);
}

void page_init_fct(void)
{

}

static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;

    if(itpGetTickDuration(g_fct_tick) <= 1000)
        set_gnd_color(0xff0000);
    else if(itpGetTickDuration(g_fct_tick) <= 2000)
        set_gnd_color(0x00ff00);
    else if(itpGetTickDuration(g_fct_tick) <= 3000)
        set_gnd_color(0x0000ff);
    else
        set_gnd_color(0x000000);

    if(get_g_factory_uart_ok())
    {
        sprintf(g_strBuffer1,"uart ok");
        lqui.set_color_param(2,0x00ff00);
    }
    else 
    {
        sprintf(g_strBuffer1,"uart ...");
        lqui.set_color_param(2,0xffffff);
    }

    ui_page_switch();
}


static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
    //TODO:
    g_fct_tick = esp_log_timestamp();
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
    g_fct_tick = esp_log_timestamp();
}

void screen_page0_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
    g_page_parent = parent_obj;

}
