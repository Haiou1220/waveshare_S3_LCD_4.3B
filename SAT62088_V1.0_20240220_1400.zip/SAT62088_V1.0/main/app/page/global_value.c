﻿#include <stdint.h>
#include "global_value.h"

uint8_t g_longKey[max_touch_key];
uint8_t g_touchKey[max_touch_key];
uint8_t g_touchKeyOld[max_touch_key];

int8_t g_main_hour = 0;
int8_t g_main_min = 0;
int8_t g_main_sec = 0;

char g_strBuffer1[120] = { 0 };
char g_strBuffer2[120] = { 0 };
char g_strBuffer3[120] = { 0 };
char g_strBuffer4[60] = { 0 };//Bigger buffer
char g_strBuffer5[60] = { 0 };//Bigger buffer
char g_strBuffer6[60] = { 0 };//Bigger buffer
char g_strBuffer7[60] = { 0 };//Bigger buffer
char g_strBuffer8[60] = { 0 };//Bigger buffer

int8_t g_curr_mode = 0;
int8_t g_flag_clearError=0;
int8_t g_flag_skipConfig = 0;
int8_t g_step_quickStart = 0;
int8_t g_index_setting = 0;

uint8_t g_index_bean_powder = 0;
uint8_t g_index_bean_powder_selecting = 0;

uint8_t g_index_tones = 0;
uint8_t g_index_tones_selecting = 0;

uint8_t g_index_filter_active = 0;
uint8_t g_index_filter_active_selecting = 0;

uint8_t g_index_water_hardness = 0;

int8_t g_index_language = 0;//0:English
int8_t g_index_language_selecting = 0;

int8_t g_index_clean = 0;//0:Rinse

int8_t g_step_coffee_process = 0;
uint8_t g_value_coffee_strength = 1;
uint16_t g_value_coffee_ml = 250;

uint8_t g_value_cup_num = 10;

uint8_t g_tp_ver;
uint8_t g_mcu_ver;
int8_t g_mcu_start;
int8_t g_mcu_mode;
int8_t g_mcu_state;
int8_t g_mcu_error;
int8_t g_mcu_clean;

int8_t  g_step_alarm_process=0;
uint8_t g_value_alarm_coffee_strength=1;
uint16_t g_value_alarm_coffee_ml=150;
uint8_t g_value_alarm_cup_num =10;

int8_t g_index_alarm_active = 0;
int8_t g_index_alarm_active_selecting = 0;

int8_t g_alarm_hour = 0;
int8_t g_alarm_min = 0;
int8_t g_alarm_sec = 0;

