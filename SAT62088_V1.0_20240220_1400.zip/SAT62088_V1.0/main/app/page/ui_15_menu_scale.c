﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE15 // 当前页面的ID序号

static int g_obj_cnt = 0; // 当前页面的控件数量

#define G_STR_BUF_TITLE             g_strBuffer1
#define G_STR_BUF_LABEL_LEFT        g_strBuffer2
#define G_STR_BUF_LABEL_RIGHT1      g_strBuffer3
#define G_STR_BUF_LABEL_RIGHT2      g_strBuffer4
#define G_STR_BUF_LABEL_UNIT        g_strBuffer5



typedef enum {
    PAGE15_OBJ_IMG_TOP = 0,
    PAGE15_OBJ_IMG_WIFI,
    PAGE15_OBJ_IMG_LINE,
    PAGE15_OBJ_LABEL_RIGHT2,
    PAGE15_OBJ_IMG_DOWN_MASK,

    PAGE15_OBJ_LABEL_TITLE,
    PAGE15_OBJ_LABEL_LEFT,
    PAGE15_OBJ_LABEL_RIGHT1,
    PAGE15_OBJ_LABEL_UNIT,
}SCREEN_PAGE15_OBJ;

//接口定义
/***************************************************/
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    {QTYPE_IMG, LINE_X,LINE_Y,&alpha_line, EXP_IMG_DEFT},
    {QTYPE_TXT, 63, 195, G_STR_BUF_LABEL_RIGHT2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0x5B5B5B,& myriadpro_regular40}}},
    {QTYPE_IMG, BG_DOWN_MASK_X,BG_DOWN_MASK_Y,&alpha_mask_down, EXP_IMG_DEFT},

    {QTYPE_TXT, -50, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, -100, LEFT_LABEL_Y, G_STR_BUF_LABEL_LEFT, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold25}}},
    {QTYPE_TXT, 63, RIGHT_LABEL_Y, G_STR_BUF_LABEL_RIGHT1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold60}}},
    {QTYPE_TXT, 130, 136, G_STR_BUF_LABEL_UNIT, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    EXP_OBJ_END };


static void wifi_auto_show(uint8_t state)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE15_OBJ_IMG_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE15_OBJ_IMG_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE15_OBJ_IMG_WIFI, TRUE);
        break;
    }
}

void page_init_menu_weight(void)
{
    //show and hid

    //set label and img
    sprintf(G_STR_BUF_TITLE, "Frozen Fench Fries");
    sprintf(G_STR_BUF_LABEL_LEFT, "Weight");
    sprintf(G_STR_BUF_LABEL_RIGHT1, "1.5");
    sprintf(G_STR_BUF_LABEL_RIGHT2, "3.2");
    sprintf(G_STR_BUF_LABEL_UNIT, "OZ");
    //to do
}



static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);
    static uint32_t flag_timesec = 0;

    ui_page_switch();
    wifi_auto_show(RunningState.wifi_state);
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}


void screen_page15_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
