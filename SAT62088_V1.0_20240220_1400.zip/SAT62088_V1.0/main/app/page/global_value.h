﻿#ifndef __GLOBAL_VALUE_H__
#define __GLOBAL_VALUE_H__

// #define TFT_VER "1.0_20230927_1702"

#include <stdint.h>

#ifdef __cplusplus
#define EXTERN extern "C" 
#else
#define EXTERN extern
#endif

#define IF_KEY_PRESS(K) if(g_touchKeyOld[K] !=g_touchKey[K]){ g_touchKeyOld[K] =g_touchKey[K];if(g_touchKey[K]){
#define END_KEY_PRESS() }}

typedef enum
{
    MICRO=0,
    AIR_FRY,
    DEFROST,
    CONV_BAKE,
    BROIL,
    SENSOR_REHEAT,
    COMBI,
    TIMER,
    AUTO_MENU,
    SETTINGS,
    KNOB_DOWN,
    KNOB_LEFT,
    KNOB_RIGHT,
    QUICK_30SEC,
    BACK_CANCEL,
    max_touch_key
}TagEnumTouchKey;

typedef enum
{
    MODE_WAIT,
    MODE_SMALL_CUP,
    MODE_LARGE_CUP,
    MODE_GLASS_JUG,
    MODE_THERMO_JUG,
    MODE_RINSE,
    MODE_DESCALEG,
    MODE_KEEP_WARN, //7
    MODE_START,
    MODE_RESET,
    MODE_SELF_EXAM=22,//自检模式
} TagEnumMode;

EXTERN int8_t g_main_hour;
EXTERN int8_t g_main_min;
EXTERN int8_t g_main_sec;

EXTERN char g_strBuffer1[120];
EXTERN char g_strBuffer2[120];
EXTERN char g_strBuffer3[120];
EXTERN char g_strBuffer4[60];
EXTERN char g_strBuffer5[60];
EXTERN char g_strBuffer6[60];
EXTERN char g_strBuffer7[60];
EXTERN char g_strBuffer8[60];

EXTERN uint8_t g_touchKey[max_touch_key];
EXTERN uint8_t g_touchKeyOld[max_touch_key];

EXTERN int8_t g_curr_mode;
EXTERN int8_t g_flag_clearError;
EXTERN int8_t g_flag_skipConfig;
EXTERN int8_t g_step_quickStart;
EXTERN int8_t g_index_setting;

EXTERN uint8_t g_index_bean_powder;
EXTERN uint8_t g_index_bean_powder_selecting;

EXTERN uint8_t g_index_tones;
EXTERN uint8_t g_index_tones_selecting;

EXTERN uint8_t g_index_filter_active;
EXTERN uint8_t g_index_filter_active_selecting;

EXTERN uint8_t g_index_water_hardness;

EXTERN int8_t g_index_language;
EXTERN int8_t g_index_language_selecting;


EXTERN int8_t g_index_clean;


EXTERN int8_t  g_step_coffee_process;
EXTERN uint8_t g_value_coffee_strength;
EXTERN uint16_t g_value_coffee_ml;

EXTERN uint8_t g_value_cup_num;

EXTERN uint8_t g_tp_ver;
EXTERN uint8_t g_mcu_ver;

EXTERN int8_t g_mcu_start;
EXTERN int8_t g_mcu_mode;
EXTERN int8_t g_mcu_state;
EXTERN int8_t g_mcu_error;
EXTERN int8_t g_mcu_clean;

EXTERN int8_t  g_step_alarm_process;
EXTERN uint8_t g_value_alarm_coffee_strength;
EXTERN uint16_t g_value_alarm_coffee_ml;
EXTERN uint8_t g_value_alarm_cup_num;

EXTERN int8_t g_index_alarm_active;
EXTERN int8_t g_index_alarm_active_selecting;

EXTERN int8_t g_alarm_hour;
EXTERN int8_t g_alarm_min;
EXTERN int8_t g_alarm_sec;



#endif // !__GLOBAL_VALUE_H__


