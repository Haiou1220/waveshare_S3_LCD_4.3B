﻿#ifndef __SCREEN_ALL_H__
#define __SCREEN_ALL_H__

#include "lvgl.h"
#include "app/lqui/lqui_base.h"
#include "app/lqui/lqui_helper.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_TAG "--"
#define TRUE    1
#define FALSE   0
#define SYSTEM_DEBUG    FALSE

#define MY_VERSION      "SAT62088 V1.0 202402201400"

#define TITLE_WIFI_X    131
#define TITLE_WIFI_Y    -97
#define BG_TOP_X    0
#define BG_TOP_Y    -88
#define BG_DOWN_X   0
#define BG_DOWN_Y   99
#define BG_DOWN_MASK_X  58
#define BG_DOWN_MASK_Y  94
#define LINE_X  -45
#define LINE_Y  7
#define TITLE_LABEL_Y   12
#define DOWN_LABEL_Y    210
#define LEFT_LABEL_Y    123
#define RIGHT_LABEL_Y    110

//#define EXP_LNE_USER {0x00,NULL,&(QuiLneParam){1,0xFF0000}} //TESTING
//{QTYPE_LNE, 0, 0,  &(lv_point_t[2]){ {CANVAS_WIDTH / 2, 0}, {CANVAS_WIDTH / 2,CANVAS_HEIGHT }}, EXP_LNE_USER},//---
//{QTYPE_LNE, 0, 0,  &(lv_point_t[2]){ {0,CANVAS_HEIGHT / 2}, {CANVAS_WIDTH,CANVAS_HEIGHT / 2 }}, EXP_LNE_USER},//|||

extern const char* g_scr_tag[];

typedef enum 
{
    PAGE0,//fct
    PAGE1,//main
    //PAGE2,//logo
    PAGE3,//POWER/TEMP
    PAGE4,//TIME-SET
    PAGE5,//working/cooking
    PAGE6,//end page
    PAGE7,//setting menu
    PAGE8,//setting details
    PAGE9,//remind details
    PAGE10,//perheat
    PAGE11,//sensor reheat
    PAGE12,
    PAGE13,
    PAGE14,
    PAGE15,

    PAGE_MAX_ID
}TagScreenIdEnum;

typedef enum {
    IdMainLock = 0, 
    IdMain, 
    IdSleep, 
    IdMicroPowerSet, 
    IdMicroTimeSet, 
    IdMicroCooking,
    IdMicroPause,
    IdMicroComplete,
    IdAirfryTempSet, 
    IdAirfryTimeSet, 
    IdAirfryCooking,
    IdAirfryPause,
    IdAirfryComplete,
    IdConvbakeTempSet, 
    IdConvbakeTimeSet,
    IdConvbakeCooking,
    IdConvbakePerheat,
    IdConvbakePause,
    IdConvbakeComplete,
    IdMenu,
    IdMenuWeight,
    IdMenuPerheat,
    IdMenuPerheatPause,
    IdMenuCooking,
    IdMenuCookingPause,
    IdMenuCookingComplete,
    IdCookingPerheatComplete,
    IdSetSound,
    IdSetLock,
    IdSetClock,
    IdSetWifi,
    IdSetAbout,
    IdOldMode,
    IdSetSoundClose,
    IdSetSoundOn,
    IdSetLockClose,
    IdSetLockOn,
    IdSetLockRemind,
    IdSetUnlock,
    IdSetClockAdjust,
    IdSetWifiWaitingConnect,
    IdSetWifiApp,
    IdSetWifiConnecting,
    IdSetWifiComplete,
    IdSetWifiConnectFail,
    IdSetWifiWaitingReset,
    IdSetWifiReset,
    IdSetWifiResetComplete,
    IdSetWifiResetFail,
    IdSetVersion,
    IdDefrostTimerSet,
    IdDefrostWorking,
    IdDefrostPause,
    IdDefrostComplete,
    IdConvbakePerheatComplete,
    IdBroilTimeSet,
    IdBroilCooking,
    IdBroilPause,
    IdBroilComplete,
    IdMenuDetails,
    IdCombiTimeSet,
    IdCombiWorking,
    IdCombiPause,
    IdCombiComplete,
    IdTimerTimeSet,//倒计时功能时间设置页面
    IdTimerWorking,
    IdTimerPause,
    IdTimerComplete,
    IdSensorReheatAddFood,//增加食物
    IdSensorReheatFoodRecognizing,//
    IdSensorReheatCooking,
    IdSensorReheatPause,
    IdSensorReheatComplete,
    IdMainLockOnRemind,

    IdFct,

    IdMax,
}ProtocolPageId;

typedef struct {
    uint8_t id; //菜单子码
    char name[30]; //菜品名字
    char utensil[30]; //器具
    char position[30]; //位置
    char cooktime[30]; //烹饪时间
    uint8_t title_offset; //标题x轴偏移
}SensorReheatStruct;

typedef struct {
    uint8_t id;
    char name[30]; //菜品名字
    char utensil[30]; //器具
    char position[30]; //位置
    char cooktime[30]; //烹饪时间
    char cookmode[30]; //烹饪模式
    uint8_t title_offset; //标题x轴偏移
}AutoMenuStruct;

typedef enum {
    SRID_0 = 0,//菜1
    SRID_Potato,//菜2-potato

    SRID_MAX,
}SensorReheatId;

typedef enum {
    AMID_0 = 0,
    AMID_1,
    AMID_2,
    AMID_3,
    AMID_4,
    AMID_5,
    AMID_6,
    AMID_7,
    AMID_8,
    AMID_FrozenFrenchFries,//10

    AMID_MAX,
}AutoMenuId;

typedef struct{
    uint8_t hour;
    uint8_t min;
    uint8_t sec;
}TimeMoreStruct;

typedef struct{
    TimeMoreStruct set;
    TimeMoreStruct cur;
    TimeMoreStruct next;
}TimeStruct;

typedef struct{
    uint16_t set;
    uint16_t cur;
    uint16_t next;
}TempStruct;

typedef struct{
    uint8_t control;
    uint8_t screen;
}VersionStruct;

typedef struct
{
    uint8_t pageid;
    uint8_t remind1;
    uint8_t remind2;
    TempStruct temp;
    TimeStruct time;
    VersionStruct version;
    uint8_t weekday;
    uint8_t power;
    uint16_t weight;
    uint8_t error;
    uint8_t steam_level;
    uint8_t wifi_state;
    uint8_t menu_index;
    bool all_page_init_success_flag;
    bool bl_switch;
    uint8_t bl_pwm;//0-100
}RunStateStruct;




extern SensorReheatStruct sr_table[SRID_MAX];
extern AutoMenuStruct am_table[AMID_MAX];
extern RunStateStruct RunningState;


#define MAX_SCREEN_ID  (PAGE_MAX_ID)

extern lv_obj_t* g_top_log_obj;
extern char g_top_log_str[];
extern int  g_top_log_cnt;
#define TOP_LOG_SIZE (512)
#define LOG_TOP(fmt,args,...) do{\
if(g_top_log_cnt>=TOP_LOG_SIZE-10){\
    memset(g_top_log_str,0,TOP_LOG_SIZE);g_top_log_cnt=0; }\
g_top_log_cnt+=sprintf(g_top_log_str+g_top_log_cnt,"[%llu] "fmt"\n",GetTickCount(),##args);\
lv_label_set_text_fmt(g_top_log_obj,"%s",g_top_log_str);\
}while(0)

#define LOG_TOP2(fmt,args,...) do{\
lv_label_set_text_fmt(g_top_log_obj,"[%d]"fmt"",GetTickCount(),##args);\
}while(0)

#define LAYOUT_INIT(parent_obj,gnd_color) do{\
    lv_obj_clear_flag(parent_obj, LV_OBJ_FLAG_SCROLLABLE);\
    lv_obj_set_style_bg_color(parent_obj, lv_color_hex(gnd_color), LV_PART_MAIN | LV_STATE_DEFAULT);\
    g_all_screenObj[CUR_SCREEN_ID].page_quit_func = screen_onQuit;\
    g_all_screenObj[CUR_SCREEN_ID].page_enter_func = screen_onEnter;\
    g_all_screenObj[CUR_SCREEN_ID].page_loop_func = screen_onHandle;\
    g_all_screenObj[CUR_SCREEN_ID].page_objs = g_objs;\
    g_all_screenObj[CUR_SCREEN_ID].parent = parent_obj;\
    g_obj_cnt = lqui_create_all_obj(g_objs, parent_obj);\
    lqui_update_all_obj(g_objs);\
    printf("#%02d# screen_page_init,obj_max=%d\n", CUR_SCREEN_ID, g_obj_cnt);\
}while(0)

void screen_tool_init();
void screen_adjust_auto(QuiObj* quiObj, int len,char* infoStr);
void screen_all_init();

//各页面的布局初始化
void screen_page0_init();
void screen_page1_init();
void screen_page3_init();
void screen_page4_init();
void screen_page5_init();
void screen_page6_init();
void screen_page7_init();
void screen_page8_init();
void screen_page9_init();
void screen_page10_init();
void screen_page11_init();
void screen_page12_init();
void screen_page13_init();
void screen_page14_init();
void screen_page15_init();

extern QuiPage* g_all_screenObj;

//=============declear image=============
LV_IMG_DECLARE(alpha_big_F);
LV_IMG_DECLARE(alpha_orange_F);
LV_IMG_DECLARE(alpha_white_F);
LV_IMG_DECLARE(alpha_mask_down);
LV_IMG_DECLARE(alpha_bg_grey);
LV_IMG_DECLARE(alpha_sound_off);
LV_IMG_DECLARE(alpha_sound_on);
LV_IMG_DECLARE(alpha_title_lock);
LV_IMG_DECLARE(alpha_title_wifi);
LV_IMG_DECLARE(alpha_wifi_connect);
LV_IMG_DECLARE(alpha_wifi_offline);
LV_IMG_DECLARE(alpha_wifi_reset);
LV_IMG_DECLARE(bg_circle);
LV_IMG_DECLARE(bg_down);
LV_IMG_DECLARE(alpha_about);
LV_IMG_DECLARE(alpha_bg_top);
LV_IMG_DECLARE(alpha_clock);
LV_IMG_DECLARE(alpha_line);
LV_IMG_DECLARE(alpha_lock_off);
LV_IMG_DECLARE(alpha_lock_off_big);
LV_IMG_DECLARE(alpha_lock_on);
LV_IMG_DECLARE(alpha_scan_box);
LV_IMG_DECLARE(alpha_lock_on_big);



LV_FONT_DECLARE(myriadpro_semibold25);
LV_FONT_DECLARE(myriadpro_semibold34);
LV_FONT_DECLARE(myriadpro_semibold40);
LV_FONT_DECLARE(myriadpro_semibold60);
LV_FONT_DECLARE(myriadpro_semibold75);
LV_FONT_DECLARE(myriadpro_semibold83);
LV_FONT_DECLARE(myriadpro_regular25);
LV_FONT_DECLARE(myriadpro_regular40);


/////////////////////////////////////////////
//my page init
/////////////////////////////////////////////
void ui_page_switch(void);

void page_init_main_lock(void);
void page_init_main(void);
void page_init_sleep(void);
void page_init_set_lock_remind(void);
void page_init_set_unlock(void);
void page_init_micro_power_set(void);
void page_init_air_fry_temp_set(void);
void page_init_conv_bake_temp_set(void);
void page_init_micro_time_set(void);
void page_init_air_fry_time_set(void);
void page_init_defrost_time_set(void);
void page_init_conv_bake_time_set(void);
void page_init_broil_time_set(void);
void page_init_combi_time_set(void);
void page_init_timer_time_set(void);
void page_init_micro_cooking(void);
void page_init_air_fry_cooking(void);
void page_init_defrost_working(void);
void page_init_conv_bake_cooking(void);
void page_init_broil_cooking(void);
void page_init_combi_working(void);
void page_init_timer_working(void);
void page_init_micro_pause(void);
void page_init_air_fry_pause(void);
void page_init_conv_bake_pause(void);
void page_init_defrost_pause(void);
void page_init_broil_pause(void);
void page_init_combi_pause(void);
void page_init_timer_pause(void);
void page_init_micro_complete(void);
void page_init_air_fry_complete(void);
void page_init_defrost_complete(void);
void page_init_conv_bake_complete(void);
void page_init_broil_complete(void);
void page_init_combi_complete(void);
void page_init_timer_complete(void);
void page_init_set_sound(void);
void page_init_set_lock(void);
void page_init_set_clock(void);
void page_init_set_wifi(void);
void page_init_set_about(void);
void page_init_set_sound_on(void);
void page_init_set_sound_close(void);
void page_init_set_lock_close(void);
void page_init_set_lock_on(void);
void page_init_set_clock_adjust(void);
void page_init_set_wifi_waiting_connect(void);
void page_init_set_wifi_waiting_reset(void);
void page_init_set_wifi_app(void);
void page_init_set_wifi_connecting(void);
void page_init_set_wifi_complete(void);
void page_init_set_version(void);
void page_init_conv_bake_perheat(void);
void page_init_conv_bake_perheat_complete(void);
void page_init_main_lock_on_remind(void);
void page_init_SensorReheatPause(void);
void page_init_SensorReheatCooking(void);
void page_init_sensor_reheat_complete(void);
void page_init_sensor_reheat_add_food(void);
void page_init_sensor_reheat_food_recognizing(void);
void page_init_set_wifi_reset_complete(void);
void page_init_set_wifi_reset(void);
void page_init_set_wifi_reset_fail(void);
void page_init_set_wifi_connect_fail(void);
void page_init_menu_cooking_complete(void);
void page_init_menu_cooking_pause(void);
void page_init_menu_cooking(void);
void page_init_menu_details(void);
void page_init_menu(void);
void page_init_menu_weight(void);
void page_init_fct(void);
bool get_g_factory_flag(void);

#endif
