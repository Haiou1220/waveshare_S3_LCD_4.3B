﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE14 // 当前页面的ID序号

static int g_obj_cnt = 0; // 当前页面的控件数量

#define G_STR_BUF_TITLE             g_strBuffer1
#define G_STR_BUF_TITLE_INDEX1      g_strBuffer2
#define G_STR_BUF_TITLE_INDEX2      g_strBuffer3
#define G_STR_BUF_LABEL1            g_strBuffer4
#define G_STR_BUF_LABEL2            g_strBuffer5
#define G_STR_BUF_LABEL3            g_strBuffer6


typedef enum {
    PAGE14_OBJ_IMG_TOP = 0,
    PAGE14_OBJ_IMG_WIFI,

    PAGE14_OBJ_LABEL_TITLE,
    PAGE14_OBJ_LABEL_INDEX1,
    PAGE14_OBJ_LABEL_INDEX2,
    PAGE14_OBJ_LABEL1,
    PAGE14_OBJ_LABEL2,
    PAGE14_OBJ_LABEL3,


}SCREEN_PAGE14_OBJ;

//接口定义
/***************************************************/
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},

    {QTYPE_TXT, -85, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 60, TITLE_LABEL_Y, G_STR_BUF_TITLE_INDEX1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xffffff,& myriadpro_semibold25}}},
    {QTYPE_TXT, 90, TITLE_LABEL_Y, G_STR_BUF_TITLE_INDEX2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0x7d7c7a,& myriadpro_semibold25}}},
    {QTYPE_TXT, 0, 90, G_STR_BUF_LABEL1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xffffff,& myriadpro_semibold40}}},
    {QTYPE_TXT, 0, 130, G_STR_BUF_LABEL2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xffffff,& myriadpro_semibold40}}},
    {QTYPE_TXT, 0, 190, G_STR_BUF_LABEL3, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},

    EXP_OBJ_END };


static void wifi_auto_show(uint8_t state)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE14_OBJ_IMG_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE14_OBJ_IMG_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE14_OBJ_IMG_WIFI, TRUE);
        break;
    }
}

void page_init_menu(void)
{
    //show and hid

    //set label and img
    sprintf(G_STR_BUF_TITLE, "Auto Menu");
    sprintf(G_STR_BUF_TITLE_INDEX1, "10");
    sprintf(G_STR_BUF_TITLE_INDEX2, "/20");
    sprintf(G_STR_BUF_LABEL1, "Frozen");
    sprintf(G_STR_BUF_LABEL2, "French Fries");
    sprintf(G_STR_BUF_LABEL3, "Air Fry");
    //to do
}


static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);
    static uint32_t flag_timesec = 0;

    ui_page_switch();
    wifi_auto_show(RunningState.wifi_state);
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}


void screen_page14_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
