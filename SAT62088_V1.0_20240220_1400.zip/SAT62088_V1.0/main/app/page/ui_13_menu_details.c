﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE13 // 当前页面的ID序号

static int g_obj_cnt = 0; // 当前页面的控件数量

#define G_STR_BUF_TITLE        g_strBuffer1
#define G_STR_BUF_LABEL1       g_strBuffer2
#define G_STR_BUF_LABEL2       g_strBuffer3
#define G_STR_BUF_LABEL3       g_strBuffer4
#define G_STR_BUF_LABEL4       g_strBuffer5
#define G_STR_BUF_LABEL5       g_strBuffer6
#define G_STR_BUF_LABEL6       g_strBuffer7
#define G_STR_BUF_DOWN         g_strBuffer8

typedef enum {
    PAGE13_OBJ_IMG_TOP = 0,
    PAGE13_OBJ_IMG_WIFI,

    PAGE13_OBJ_LABEL_TITLE,
    PAGE13_OBJ_LABEL1,
    PAGE13_OBJ_LABEL2,
    PAGE13_OBJ_LABEL3,
    PAGE13_OBJ_LABEL4,
    PAGE13_OBJ_LABEL5,
    PAGE13_OBJ_LABEL6,

    PAGE13_OBJ_IMG_DOWN,
    PAGE13_OBJ_LABEL_DOWN,

}SCREEN_PAGE13_OBJ;

//接口定义
/***************************************************/
static int cntsec = 0;
static bool g_remind = 0;//0-hid/1-show 5 sec
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},

    {QTYPE_TXT, -50, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 20, 70, G_STR_BUF_LABEL1, {LQ_OBJ_FLAG_LEFT,NULL,&(QuiTxtParam){0xb0b0af,& myriadpro_semibold25}}},
    {QTYPE_TXT, 125, 70, G_STR_BUF_LABEL2, {LQ_OBJ_FLAG_LEFT,NULL,&(QuiTxtParam){0xb0b0af,& myriadpro_semibold25}}},
    {QTYPE_TXT, 20, 110, G_STR_BUF_LABEL3, {LQ_OBJ_FLAG_LEFT,NULL,&(QuiTxtParam){0xb0b0af,& myriadpro_semibold25}}},
    {QTYPE_TXT, 135, 110, G_STR_BUF_LABEL4, {LQ_OBJ_FLAG_LEFT,NULL,&(QuiTxtParam){0xb0b0af,& myriadpro_semibold25}}},
    {QTYPE_TXT, 20, 150, G_STR_BUF_LABEL5, {LQ_OBJ_FLAG_LEFT,NULL,&(QuiTxtParam){0xb0b0af,& myriadpro_semibold25}}},
    {QTYPE_TXT, 155, 150, G_STR_BUF_LABEL6, {LQ_OBJ_FLAG_LEFT,NULL,&(QuiTxtParam){0xb0b0af,& myriadpro_semibold25}}},

    {QTYPE_IMG, BG_DOWN_X,BG_DOWN_Y,&bg_down, EXP_IMG_DEFT},
    {QTYPE_TXT, 0, DOWN_LABEL_Y, G_STR_BUF_DOWN, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_regular25}}},

    EXP_OBJ_END };

static void clean_remind(void)
{
    cntsec = g_main_sec;
}


static void remind_run(void)
{
    const char* remind_text1[2] = { "Press\"Start\"to cook","Press\"Start\"to cook" };
    const char* remind_text2[2] = { "Press\"Start\"to cook","Press\"Start\"to cook" };

    if (g_remind)
    {
        lqui.show_obj(PAGE13_OBJ_IMG_DOWN, TRUE);
        lqui.show_obj(PAGE13_OBJ_LABEL_DOWN, TRUE);

        if ((g_main_sec - cntsec) < 3)
            lqui.set_text(PAGE13_OBJ_LABEL_DOWN, remind_text1[0]);
        else if ((g_main_sec - cntsec) >= 6)
        {
            lqui.show_obj(PAGE13_OBJ_IMG_DOWN, FALSE);
            lqui.show_obj(PAGE13_OBJ_LABEL_DOWN, FALSE);
            g_remind = 0;
        }
        else
            lqui.set_text(PAGE13_OBJ_LABEL_DOWN, remind_text2[0]);
    }
    else
    {
        lqui.show_obj(PAGE13_OBJ_IMG_DOWN, FALSE);
        lqui.show_obj(PAGE13_OBJ_LABEL_DOWN, FALSE);
        clean_remind();
    }
}

static void wifi_auto_show(uint8_t state)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE13_OBJ_IMG_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE13_OBJ_IMG_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE13_OBJ_IMG_WIFI, TRUE);
        break;
    }
}



void page_init_menu_details(void)
{
    //show and hid

    //set label and img
    sprintf(G_STR_BUF_TITLE, "Frozen Fench Fries");
    sprintf(G_STR_BUF_LABEL1, "Utensil:");
    sprintf(G_STR_BUF_LABEL2, "Roasting Pan");
    sprintf(G_STR_BUF_LABEL3, "Position:");
    sprintf(G_STR_BUF_LABEL4, "Middle");
    sprintf(G_STR_BUF_LABEL5, "Cook Time:");
    sprintf(G_STR_BUF_LABEL6, "6min");
    //to do
    g_remind = TRUE;
    clean_remind();
}


static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);
    static uint32_t flag_timesec = 0;

    ui_page_switch();
    wifi_auto_show(RunningState.wifi_state);
    remind_run();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
    clean_remind();
}


void screen_page13_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
