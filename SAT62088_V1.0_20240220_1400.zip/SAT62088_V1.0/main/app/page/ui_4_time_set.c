﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE4 // 当前页面的ID序号
#define G_STR_BUF_RIGHT2    g_strBuffer1
#define G_STR_BUF_TITLE     g_strBuffer2
#define G_STR_BUF_LEFT      g_strBuffer3
#define G_STR_BUF_DOWN      g_strBuffer4
#define G_STR_BUF_RIGHT     g_strBuffer5
#define G_STR_BUF_TIME1     g_strBuffer6
#define G_STR_BUF_TIME2     g_strBuffer7

static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE4_OBJ_IMG_LINE = 0,
    PAGE4_OBJ_IMG_TOP,
    PAGE4_OBJ_LABEL_RIGHT2,
    PAGE4_OBJ_IMG_DOWN_MASK,
    PAGE4_OBJ_IMG_DOWN,
    PAGE4_OBJ_IMG_TITLE_WIFI,

    PAGE4_OBJ_LABEL_TITLE,
    PAGE4_OBJ_LABEL_LEFT,
    PAGE4_OBJ_LABEL_DOWN,
    PAGE4_OBJ_LABEL_RIGHT,
    PAGE4_OBJ_LABEL_TIME1,
    PAGE4_OBJ_LABEL_TIME2,
    
}SCREEN_PAGE4_OBJ;

//单独控件
/***************************************************/

/***************************************************/
//接口定义
/***************************************************/

static int cntsec = 0;
static bool g_remind = 0;//0-hid/1-show 5 sec
static bool g_timemode = 0;//0-min.sec/1-hour.min
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, LINE_X,LINE_Y,&alpha_line, EXP_IMG_DEFT},
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_TXT, 63, 195, G_STR_BUF_RIGHT2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0x5B5B5B,& myriadpro_regular40}}},
    {QTYPE_IMG, BG_DOWN_MASK_X,BG_DOWN_MASK_Y,&alpha_mask_down, EXP_IMG_DEFT},
    {QTYPE_IMG, BG_DOWN_X,BG_DOWN_Y,&bg_down, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    
    {QTYPE_TXT, -90, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, -100, LEFT_LABEL_Y, G_STR_BUF_LEFT, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold25}}},
    {QTYPE_TXT, 0, DOWN_LABEL_Y, G_STR_BUF_DOWN, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_regular25}}},
    {QTYPE_TXT, 63, RIGHT_LABEL_Y, G_STR_BUF_RIGHT, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold60}}},
    {QTYPE_TXT, 25, 79, G_STR_BUF_TIME1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xB6B7B7,& myriadpro_regular25}}},
    {QTYPE_TXT, 103, 79, G_STR_BUF_TIME2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xB6B7B7,& myriadpro_regular25}}},
    EXP_OBJ_END };

static void clean_remind(void)
{
    cntsec = g_main_sec;
}

static bool remind_run(bool remindflag)
{
    if (remindflag)
    {
        lqui.show_obj(PAGE4_OBJ_IMG_DOWN, TRUE);
        lqui.show_obj(PAGE4_OBJ_LABEL_DOWN, TRUE);

        if ((g_main_sec - cntsec) < 3)
            sprintf(G_STR_BUF_DOWN,"Knob setting");
        else if ((g_main_sec - cntsec) >= 6)
        {
            lqui.show_obj(PAGE4_OBJ_IMG_DOWN, FALSE);
            lqui.show_obj(PAGE4_OBJ_LABEL_DOWN, FALSE);
            remindflag = 0;
        }
        else
            sprintf(G_STR_BUF_DOWN,"or press \"START\" to next");
    }
    else
    {
        lqui.show_obj(PAGE4_OBJ_IMG_DOWN, FALSE);
        lqui.show_obj(PAGE4_OBJ_LABEL_DOWN, FALSE);
        clean_remind();
    }

    return remindflag;
}

static void wifi_auto_show(uint8_t state)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE4_OBJ_IMG_TITLE_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE4_OBJ_IMG_TITLE_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE4_OBJ_IMG_TITLE_WIFI, TRUE);
        break;
    }
}

static void value_set(uint8_t curhour,uint8_t curmin,uint8_t cursec,uint8_t nexthour,uint8_t nextmin,uint8_t nextsec,bool modeflag)
{
    static char stext1[20] = { 0 };
    static char stext2[20] = { 0 };
    if (modeflag) //hour.min
    {
        sprintf(G_STR_BUF_RIGHT, "%02d:%02d", curhour, curmin);
        sprintf(G_STR_BUF_RIGHT2,"%02d:%02d", nexthour, nextmin);
    }
    else //min.sec
    {
        sprintf(G_STR_BUF_RIGHT, "%02d:%02d", curmin, cursec);
        sprintf(G_STR_BUF_RIGHT2, "%02d:%02d", nextmin, nextsec);
    }
    
}

void page_init_micro_time_set(void) 
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Microwave");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"min");
    sprintf(G_STR_BUF_TIME2,"sec");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -90, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = FALSE; //min.sec
}

void page_init_air_fry_time_set(void) 
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Air Fry");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = TRUE; //h.min
}

void page_init_defrost_time_set(void)
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Defrost");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -105, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = TRUE; //h.min
}

void page_init_conv_bake_time_set(void)
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Conv.Bake");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -90, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = TRUE; //h.min
}

void page_init_broil_time_set(void)
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Broil");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -120, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = TRUE; //h.min
}

void page_init_combi_time_set(void)
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Combi");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = TRUE; //h.min
}

void page_init_timer_time_set(void)
{
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Timer");
    sprintf(G_STR_BUF_LEFT,"Time");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE4_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
    g_timemode = TRUE; //h.min
}


static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);

    ui_page_switch();
    g_remind = remind_run(g_remind);
    value_set(RunningState.time.set.hour, RunningState.time.set.min, RunningState.time.set.sec, RunningState.time.next.hour, RunningState.time.next.min, RunningState.time.next.sec, g_timemode);
    wifi_auto_show(RunningState.wifi_state);
    
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
    clean_remind();
}

//////////////////////////////////////////////////////////////////////////


void screen_page4_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
