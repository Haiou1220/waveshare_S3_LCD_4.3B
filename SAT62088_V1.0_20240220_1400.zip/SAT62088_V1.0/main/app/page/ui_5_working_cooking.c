﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE5 // 当前页面的ID序号
#define G_STR_BUF_TITLE     g_strBuffer1
#define G_STR_BUF_MODE      g_strBuffer2
#define G_STR_BUF_TIME      g_strBuffer3
#define G_STR_BUF_UNIT1     g_strBuffer4
#define G_STR_BUF_UNIT2     g_strBuffer5
#define G_STR_BUF_DOWN      g_strBuffer6

static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE5_OBJ_IMG_BG,
    PAGE5_OBJ_IMG_TITLE_WIFI,
    PAGE5_OBJ_IMG_TEMP_UNIT,

    PAGE5_OBJ_LABEL_TITLE,
    PAGE5_OBJ_LABEL_MODE,
    PAGE5_OBJ_LABEL_TIME,
    PAGE5_OBJ_LABEL_UNIT1,
    PAGE5_OBJ_LABEL_UNIT2,

    PAGE5_OBJ_IMG_DOWN,
    PAGE5_OBJ_LABEL_DOWN,
    
}SCREEN_PAGE5_OBJ;

typedef enum {
    PAGE5_OBJ_MODE_INDEX_POWER = 0,//high、middle、low
    PAGE5_OBJ_MODE_INDEX_TEMP, 
    PAGE5_OBJ_MODE_INDEX_COOKING,//cooking
    PAGE5_OBJ_MODE_INDEX_NONE,//none

    PAGE5_OBJ_MODE_MAX,
}SCREEN_PAGE5_OBJ_MODE_INDEX;

//单独控件
/***************************************************/

/***************************************************/
//接口定义
/***************************************************/
static bool g_timemode = 0;//0-min.sec/1-hour.min
static uint8_t g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_NONE;
// static uint8_t g_menu_index = 0;
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, 0,0,&bg_circle, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    {QTYPE_IMG, 35,-39,&alpha_orange_F, EXP_IMG_DEFT},
    
    {QTYPE_TXT, -90, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 0, 73, G_STR_BUF_MODE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xE86B10,& myriadpro_regular25}}},
    {QTYPE_TXT, 0, 100, G_STR_BUF_TIME, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold75}}},
    {QTYPE_TXT, -50, 168, G_STR_BUF_UNIT1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xB6B7B7,& myriadpro_regular25}}},
    {QTYPE_TXT, 50, 168, G_STR_BUF_UNIT2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xB6B7B7,& myriadpro_regular25}}},

    {QTYPE_IMG, BG_DOWN_X,BG_DOWN_Y,&bg_down, EXP_IMG_DEFT},
    {QTYPE_TXT, 0, DOWN_LABEL_Y, G_STR_BUF_DOWN, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_regular25}}},
    EXP_OBJ_END };


static void pause_onoff(bool onoff)//1-pause/0-work
{
    if (onoff)//pause
    {
        sprintf(G_STR_BUF_DOWN,"Press \"Start\" to cook");
        lqui.set_color_param(PAGE5_OBJ_LABEL_TIME, 0x808080);
        lqui.show_obj(PAGE5_OBJ_IMG_DOWN, TRUE);
        lqui.show_obj(PAGE5_OBJ_LABEL_DOWN, TRUE);
    }
    else //cancel pause
    {
        lqui.set_color_param(PAGE5_OBJ_LABEL_TIME, 0xffffff);
        lqui.show_obj(PAGE5_OBJ_IMG_DOWN, FALSE);
        lqui.show_obj(PAGE5_OBJ_LABEL_DOWN, FALSE);
    }
}

static void wifi_auto_show(uint8_t state)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE5_OBJ_IMG_TITLE_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE5_OBJ_IMG_TITLE_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE5_OBJ_IMG_TITLE_WIFI, TRUE);
        break;
    }
}

static void value_set(uint8_t curhour,uint8_t curmin,uint8_t cursec,bool modeflag)
{
    static char stext[20] = { 0 };
    if (modeflag) //hour.min
    {
        sprintf(G_STR_BUF_TIME, "%02d:%02d", curhour, curmin);
    }
    else //min.sec
    {
        sprintf(G_STR_BUF_TIME, "%02d:%02d", curmin, cursec);
    }   
}

static void mode_set(uint8_t modeindex)
{
    switch (modeindex)
    {
    case PAGE5_OBJ_MODE_INDEX_POWER:
        if (RunningState.power == 1)
            sprintf(G_STR_BUF_MODE,"Low");
        else if(RunningState.power == 5)
            sprintf(G_STR_BUF_MODE,"Middle");
        else if(RunningState.power == 10)
            sprintf(G_STR_BUF_MODE,"High");
        break;
    case PAGE5_OBJ_MODE_INDEX_TEMP:
        sprintf(G_STR_BUF_MODE, "%d", RunningState.temp.set);
        break;
    case PAGE5_OBJ_MODE_INDEX_COOKING:
        sprintf(G_STR_BUF_MODE,"Cooking");
        break;
    case PAGE5_OBJ_MODE_INDEX_NONE:
        break;
    }
}

void page_init_micro_cooking(void) 
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, TRUE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Microwave");
    sprintf(G_STR_BUF_UNIT1,"min");
    sprintf(G_STR_BUF_UNIT2,"sec");
    sprintf(G_STR_BUF_MODE,"High");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_POWER;
    g_timemode = FALSE; //min.sec
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -90, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_air_fry_cooking(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, TRUE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, TRUE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Air Fry");
    sprintf(G_STR_BUF_UNIT1,"h");
    sprintf(G_STR_BUF_UNIT2,"min");
    sprintf(G_STR_BUF_MODE,"450");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_TEMP;
    g_timemode = TRUE; //h.min
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_defrost_working(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, FALSE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Defrost");
    sprintf(G_STR_BUF_UNIT1,"h");
    sprintf(G_STR_BUF_UNIT2,"min");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_NONE;
    g_timemode = TRUE; //h.min
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -105, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_conv_bake_cooking(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, TRUE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, TRUE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Conv.Bake");
    sprintf(G_STR_BUF_UNIT1,"h");
    sprintf(G_STR_BUF_UNIT2,"min");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_TEMP;
    g_timemode = TRUE; //h.min
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -90, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_broil_cooking(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, FALSE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Broil");
    sprintf(G_STR_BUF_UNIT1,"h");
    sprintf(G_STR_BUF_UNIT2,"min");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_NONE;
    g_timemode = TRUE; //h.min
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -120, TITLE_LABEL_Y);
    pause_onoff(0);
}



void page_init_combi_working(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, FALSE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Combi");
    sprintf(G_STR_BUF_UNIT1,"h");
    sprintf(G_STR_BUF_UNIT2,"min");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_NONE;
    g_timemode = TRUE; //h.min
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_timer_working(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, FALSE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Timer");
    sprintf(G_STR_BUF_UNIT1,"h");
    sprintf(G_STR_BUF_UNIT2,"min");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_NONE;
    g_timemode = TRUE; //h.min
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_micro_pause(void)
{
    page_init_micro_cooking();
    pause_onoff(1);
}

void page_init_air_fry_pause(void)
{
    page_init_air_fry_cooking();
    pause_onoff(1);
}

void page_init_conv_bake_pause(void)
{
    page_init_conv_bake_cooking();
    pause_onoff(1);
}

void page_init_defrost_pause(void)
{
    page_init_defrost_working();
    pause_onoff(1);
}

void page_init_broil_pause(void)
{
    page_init_broil_cooking();
    pause_onoff(1);
}

void page_init_combi_pause(void)
{
    page_init_combi_working();
    pause_onoff(1);
}

void page_init_timer_pause(void)
{
    page_init_timer_working();
    pause_onoff(1);
}

void page_init_SensorReheatCooking(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, TRUE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Sensor Reheat");
    sprintf(G_STR_BUF_UNIT1,"min");
    sprintf(G_STR_BUF_UNIT2,"sec");
    sprintf(G_STR_BUF_MODE,"Cooking");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_COOKING;
    g_timemode = FALSE; //min.sec
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -70, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_SensorReheatPause(void)
{
    page_init_SensorReheatCooking();
    pause_onoff(1);
}

void page_init_menu_cooking(void)
{
    //show and hid
    lqui.show_obj(PAGE5_OBJ_IMG_TEMP_UNIT, FALSE);
    lqui.show_obj(PAGE5_OBJ_LABEL_MODE, TRUE);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Frozen Fench Fries");
    sprintf(G_STR_BUF_UNIT1,"min");
    sprintf(G_STR_BUF_UNIT2,"sec");
    sprintf(G_STR_BUF_MODE,"Cooking");
    //to do
    g_obj_mode_index = PAGE5_OBJ_MODE_INDEX_COOKING;
    g_timemode = FALSE; //min.sec
    lqui.set_pos(PAGE5_OBJ_LABEL_TITLE, -50, TITLE_LABEL_Y);
    pause_onoff(0);
}

void page_init_menu_cooking_pause(void)
{
    page_init_menu_cooking();
    pause_onoff(1);
}

static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);
    ui_page_switch();
    wifi_auto_show(RunningState.wifi_state);
    mode_set(g_obj_mode_index);
    value_set(RunningState.time.set.hour,RunningState.time.set.min,RunningState.time.set.sec, g_timemode);
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}

//////////////////////////////////////////////////////////////////////////


void screen_page5_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
