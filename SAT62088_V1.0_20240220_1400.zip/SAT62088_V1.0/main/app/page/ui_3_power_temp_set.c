﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE3 // 当前页面的ID序号
#define G_STR_BUF_RIGHT2    g_strBuffer1
#define G_STR_BUF_TITLE     g_strBuffer2
#define G_STR_BUF_LEFT      g_strBuffer3
#define G_STR_BUF_DOWN      g_strBuffer4
#define G_STR_BUF_RIGHT     g_strBuffer5
static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE3_OBJ_IMG_LINE = 0,
    PAGE3_OBJ_IMG_TOP,
    PAGE3_OBJ_LABEL_RIGHT2,
    PAGE3_OBJ_IMG_DOWN_MASK,
    PAGE3_OBJ_IMG_DOWN,
    PAGE3_OBJ_IMG_TITLE_WIFI,
    //PAGE3_OBJ_IMG_LEFT,
    PAGE3_OBJ_IMG_F,

    PAGE3_OBJ_LABEL_TITLE,
    PAGE3_OBJ_LABEL_LEFT,
    PAGE3_OBJ_LABEL_DOWN,
    PAGE3_OBJ_LABEL_RIGHT,

    
}SCREEN_PAGE3_OBJ;

//单独控件
/***************************************************/
static lv_obj_t* roller1;
static lv_obj_t* label1;
/***************************************************/
//接口定义
/***************************************************/
static int cntsec = 0;
static bool g_remind = 0;//0-hid/1-show 5 sec
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, LINE_X,LINE_Y,&alpha_line, EXP_IMG_DEFT},
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_TXT, 63, 195, g_strBuffer1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0x5B5B5B,& myriadpro_regular40}}},
    {QTYPE_IMG, BG_DOWN_MASK_X,BG_DOWN_MASK_Y,&alpha_mask_down, EXP_IMG_DEFT},
    {QTYPE_IMG, BG_DOWN_X,BG_DOWN_Y,&bg_down, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    //{QTYPE_IMG, -98,4,&alpha_sound_off, EXP_IMG_DEFT},
    {QTYPE_IMG, 121,-14,&alpha_white_F, EXP_IMG_DEFT},
    
    {QTYPE_TXT, -90, TITLE_LABEL_Y, g_strBuffer2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, -100, LEFT_LABEL_Y, g_strBuffer3, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold25}}},
    {QTYPE_TXT, 0, DOWN_LABEL_Y, g_strBuffer4, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_regular25}}},
    {QTYPE_TXT, 63, RIGHT_LABEL_Y, g_strBuffer5, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xE86B10,& myriadpro_semibold60}}},

    EXP_OBJ_END };

static void hid_all_obj(void)
{
    lqui.show_all(g_objs, FALSE);
}

static void show_cur_obj(uint8_t* index,uint8_t len)//参数是带obj index的静态数组
{
    for (int i = 0; i < len; i++)
    {
        lqui.show_obj(index[i],true);
    }
}

static void clean_remind(void)
{
    cntsec = g_main_sec;
}

static void remind_run(void)
{
    if (g_remind)
    {
        lqui.show_obj(PAGE3_OBJ_IMG_DOWN, TRUE);
        lqui.show_obj(PAGE3_OBJ_LABEL_DOWN, TRUE);

        if ((g_main_sec - cntsec) < 3)
            sprintf(G_STR_BUF_DOWN,"Knob setting");
        else if ((g_main_sec - cntsec) >= 6)
        {
            lqui.show_obj(PAGE3_OBJ_IMG_DOWN, FALSE);
            lqui.show_obj(PAGE3_OBJ_LABEL_DOWN, FALSE);
            g_remind = 0;
        }
        else
            sprintf(G_STR_BUF_DOWN,"or press \"START\" to next");
    }
    else
    {
        lqui.show_obj(PAGE3_OBJ_IMG_DOWN, FALSE);
        lqui.show_obj(PAGE3_OBJ_LABEL_DOWN, FALSE);
        clean_remind();
    }
}

static void wifi_auto_show(void)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (RunningState.wifi_state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE3_OBJ_IMG_TITLE_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE3_OBJ_IMG_TITLE_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE3_OBJ_IMG_TITLE_WIFI, TRUE);
        break;
    }
}


static void value_run(void)
{
    static const char* power_table1[3] = {"Low","Middle","High",};
    static const uint8_t power_table2[3] = { 1,5,10 };
    char temp_text1[20] = {0};
    char temp_text2[20] = {0};

    if (RunningState.pageid == IdMicroPowerSet)
    {
        for (int i = 0; i < 3; i++)
        {
            if (RunningState.power == power_table2[i])
            {
                sprintf(G_STR_BUF_RIGHT,power_table1[i]);
                if (i > 0)
                {
                    lqui.show_obj(PAGE3_OBJ_LABEL_RIGHT2, TRUE);
                    sprintf(G_STR_BUF_RIGHT2,power_table1[i - 1]);
                }
                else
                    lqui.show_obj(PAGE3_OBJ_LABEL_RIGHT2, FALSE);
            }
        }
    }
    else if (RunningState.pageid == IdAirfryTempSet)
    {
        sprintf(G_STR_BUF_RIGHT,"%d",RunningState.temp.set);
        sprintf(G_STR_BUF_RIGHT2,"%d",RunningState.temp.next);
    }
    else if (RunningState.pageid == IdConvbakeTempSet)
    {
        sprintf(G_STR_BUF_RIGHT,"%d",RunningState.temp.set);
        sprintf(G_STR_BUF_RIGHT2,"%d",RunningState.temp.next);
    }
}


void page_init_micro_power_set(void)  
{
    static const uint8_t show_index[8] = { PAGE3_OBJ_IMG_TOP ,PAGE3_OBJ_IMG_TITLE_WIFI ,PAGE3_OBJ_IMG_LINE ,PAGE3_OBJ_IMG_DOWN_MASK,
        PAGE3_OBJ_LABEL_TITLE,PAGE3_OBJ_LABEL_LEFT,PAGE3_OBJ_LABEL_RIGHT,PAGE3_OBJ_LABEL_RIGHT2,
    };
    ///show obj
    hid_all_obj();
    show_cur_obj(show_index,8);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Microwave");
    sprintf(G_STR_BUF_LEFT,"Power");
    sprintf(G_STR_BUF_RIGHT,"High");
    sprintf(G_STR_BUF_RIGHT2,"Middle");
    //to do
    lqui.set_pos(PAGE3_OBJ_LABEL_TITLE, -90, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
}

void page_init_air_fry_temp_set(void)  
{
    static const uint8_t show_index[9] = { PAGE3_OBJ_IMG_TOP ,PAGE3_OBJ_IMG_TITLE_WIFI ,PAGE3_OBJ_IMG_LINE ,PAGE3_OBJ_IMG_F,PAGE3_OBJ_IMG_DOWN_MASK,
        PAGE3_OBJ_LABEL_TITLE,PAGE3_OBJ_LABEL_LEFT,PAGE3_OBJ_LABEL_RIGHT,PAGE3_OBJ_LABEL_RIGHT2,
    };
    ///show obj
    hid_all_obj();
    show_cur_obj(show_index,9);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Air Fry");
    sprintf(G_STR_BUF_LEFT,"Temp.");
    //to do
    g_remind = TRUE;
    lqui.set_pos(PAGE3_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    clean_remind();
}

void page_init_conv_bake_temp_set(void)  
{
    static const uint8_t show_index[9] = { PAGE3_OBJ_IMG_TOP ,PAGE3_OBJ_IMG_TITLE_WIFI ,PAGE3_OBJ_IMG_LINE ,PAGE3_OBJ_IMG_F,PAGE3_OBJ_IMG_DOWN_MASK,
        PAGE3_OBJ_LABEL_TITLE,PAGE3_OBJ_LABEL_LEFT,PAGE3_OBJ_LABEL_RIGHT,PAGE3_OBJ_LABEL_RIGHT2,
    };
    ///show obj
    hid_all_obj();
    show_cur_obj(show_index,9);
    //set label and img
    sprintf(G_STR_BUF_TITLE,"Conv.Bake");
    sprintf(G_STR_BUF_LEFT,"Temp.");
    //to do
    g_remind = TRUE;
    lqui.set_pos(PAGE3_OBJ_LABEL_TITLE, -90, TITLE_LABEL_Y);
    clean_remind();
}



static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);

    ui_page_switch();
    remind_run();
    value_run();
    wifi_auto_show();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
    clean_remind();
}

//////////////////////////////////////////////////////////////////////////


void screen_page3_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
