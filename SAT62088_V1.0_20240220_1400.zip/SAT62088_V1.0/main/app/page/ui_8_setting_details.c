﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE8 // 当前页面的ID序号
#define G_STR_BUF_RIGHT2    g_strBuffer1
#define G_STR_BUF_TITLE     g_strBuffer2
#define G_STR_BUF_RIGHT     g_strBuffer3
#define G_STR_BUF_TIME1     g_strBuffer4
#define G_STR_BUF_TIME2     g_strBuffer5
static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE8_OBJ_IMG_LINE = 0,
    PAGE8_OBJ_IMG_TOP,
    PAGE8_OBJ_LABEL_RIGHT2,
    PAGE8_OBJ_IMG_DOWN_MASK,
    PAGE8_OBJ_IMG_TITLE_WIFI,
    PAGE8_OBJ_IMG_LEFT,

    PAGE8_OBJ_LABEL_TITLE,
    PAGE8_OBJ_LABEL_RIGHT,
    PAGE8_OBJ_LABEL_TIME1,
    PAGE8_OBJ_LABEL_TIME2,
    
}SCREEN_PAGE8_OBJ;

//单独控件
/***************************************************/

/***************************************************/
//接口定义
/***************************************************/

/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, LINE_X,LINE_Y,&alpha_line, EXP_IMG_DEFT},
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_TXT, 63, 195, G_STR_BUF_RIGHT2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0x5B5B5B,& myriadpro_regular40}}},
    {QTYPE_IMG, BG_DOWN_MASK_X,BG_DOWN_MASK_Y,&alpha_mask_down, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    {QTYPE_IMG, -101,14,&alpha_sound_on, EXP_IMG_DEFT},
    
    {QTYPE_TXT, -90, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 63, RIGHT_LABEL_Y, G_STR_BUF_RIGHT, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold60}}},
    {QTYPE_TXT, 25, 79, G_STR_BUF_TIME1, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xB6B7B7,& myriadpro_regular25}}},
    {QTYPE_TXT, 103, 79, G_STR_BUF_TIME2, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xB6B7B7,& myriadpro_regular25}}},
    EXP_OBJ_END };

static void wifi_auto_show(uint8_t state)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE8_OBJ_IMG_TITLE_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE8_OBJ_IMG_TITLE_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE8_OBJ_IMG_TITLE_WIFI, TRUE);
        break;
    }
}

static void ObjShowMode(uint8_t mode)//0-on off mode/1-clock mode/2-wifi mode
{
    switch (mode)
    {
    case 0://on off mode
        lqui.show_obj(PAGE8_OBJ_LABEL_TIME1, FALSE);
        lqui.show_obj(PAGE8_OBJ_LABEL_TIME2, FALSE);
        lqui.show_obj(PAGE8_OBJ_LABEL_RIGHT2, TRUE);
        lqui.show_obj(PAGE8_OBJ_IMG_DOWN_MASK, TRUE);
        break;
    case 1://clock mode
        lqui.show_obj(PAGE8_OBJ_LABEL_TIME1, TRUE);
        lqui.show_obj(PAGE8_OBJ_LABEL_TIME2, TRUE);
        lqui.show_obj(PAGE8_OBJ_LABEL_RIGHT2, TRUE);
        lqui.show_obj(PAGE8_OBJ_IMG_DOWN_MASK, TRUE);
        break;
    case 2://wifi mode
        lqui.show_obj(PAGE8_OBJ_LABEL_TIME1, FALSE);
        lqui.show_obj(PAGE8_OBJ_LABEL_TIME2, FALSE);
        lqui.show_obj(PAGE8_OBJ_LABEL_RIGHT2, FALSE);
        lqui.show_obj(PAGE8_OBJ_IMG_DOWN_MASK, FALSE);
        break;
    }
}

void page_init_set_sound_on(void)
{
    //obj show hid
    ObjShowMode(0);
    //set label and img
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_sound_on);
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold60);
    sprintf(G_STR_BUF_TITLE,"Sound");
    sprintf(G_STR_BUF_RIGHT,"ON");
    sprintf(G_STR_BUF_RIGHT2,"Off");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 110);
}

void page_init_set_sound_close(void)
{
    //obj show hid
    ObjShowMode(0);
    //set label and img
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold60);
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_sound_off);
    sprintf(G_STR_BUF_TITLE,"Sound");
    sprintf(G_STR_BUF_RIGHT,"OFF");
    sprintf(G_STR_BUF_RIGHT2,"On");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -110, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 110);
}

void page_init_set_lock_close(void)
{
    //obj show hid
    ObjShowMode(0);
    //set label and img
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_lock_off);
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold60);
    sprintf(G_STR_BUF_TITLE,"Child Lock");
    sprintf(G_STR_BUF_RIGHT,"OFF");
    sprintf(G_STR_BUF_RIGHT2,"On");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -95, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 110);
}

void page_init_set_lock_on(void)
{
    //obj show hid
    ObjShowMode(0);
    //set label and img
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_lock_on);
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold60);
    sprintf(G_STR_BUF_TITLE,"Child Lock");
    sprintf(G_STR_BUF_RIGHT,"ON");
    sprintf(G_STR_BUF_RIGHT2,"Off");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -95, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 110);
}

void page_init_set_clock_adjust(void)
{
    //obj show hid
    ObjShowMode(1);
    //set label and img
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_clock);
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold60);
    sprintf(G_STR_BUF_TITLE,"Clock");
    sprintf(G_STR_BUF_RIGHT,"00:00");
    sprintf(G_STR_BUF_RIGHT2,"01:00");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -120, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 110);
}

void page_init_set_wifi_waiting_connect(void)
{
    //obj show hid
    ObjShowMode(2);
    //set label and img
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_wifi_offline);
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold40);
    sprintf(G_STR_BUF_TITLE,"Connect");
    sprintf(G_STR_BUF_RIGHT,"To Link");
    sprintf(G_STR_BUF_RIGHT2,"Off");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -100, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 120);
}

static void value_run(void)
{
    static char text1[15] = { 0 };
    static char text2[15] = { 0 };
    if (RunningState.pageid == IdSetClockAdjust)
    {
        sprintf(G_STR_BUF_RIGHT, "%02d:%02d", RunningState.time.set.hour,RunningState.time.set.min);
        sprintf(G_STR_BUF_RIGHT2, "%02d:%02d", RunningState.time.next.hour,RunningState.time.next.min);
    }
}

void page_init_set_wifi_waiting_reset(void)
{
    //obj show hid
    ObjShowMode(2);
    //set label and img
    lqui.set_img_src(PAGE8_OBJ_IMG_LEFT, &alpha_wifi_reset);
    lqui.set_font(PAGE8_OBJ_LABEL_RIGHT, &myriadpro_semibold40);
    sprintf(G_STR_BUF_TITLE,"Connect");
    sprintf(G_STR_BUF_RIGHT,"Reset");
    sprintf(G_STR_BUF_RIGHT2,"Off");
    sprintf(G_STR_BUF_TIME1,"h");
    sprintf(G_STR_BUF_TIME2,"min");
    //to do
    lqui.set_pos(PAGE8_OBJ_LABEL_TITLE, -100, TITLE_LABEL_Y);
    lqui.set_pos(PAGE8_OBJ_LABEL_RIGHT, 63, 120);
}

 

static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);

    ui_page_switch();
    wifi_auto_show(RunningState.wifi_state);
    value_run();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}

//////////////////////////////////////////////////////////////////////////


void screen_page8_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
