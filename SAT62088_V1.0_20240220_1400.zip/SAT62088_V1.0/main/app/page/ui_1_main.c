﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE1 // 当前页面的ID序号
#define G_STR_BUF_TITLE     g_strBuffer5
#define G_STR_BUF_TIME      g_strBuffer4
#define G_STR_BUF_REMIND    g_strBuffer3

static int g_obj_cnt = 0; // 当前页面的控件数量

typedef enum {
    PAGE1_OBJ_IMG_TOP = 0,
    PAGE1_OBJ_IMG_WIFI,
    PAGE1_OBJ_IMG_LOCK,
    PAGE1_OBJ_LABEL_TITLE,
    PAGE1_OBJ_LABEL_TIME,

    PAGE1_OBJ_IMG_REMIND,
    PAGE1_OBJ_LABEL_REMIND,
    PAGE1_OBJ_IMG_LOCK_BIG,
}SCREEN_PAGE1_OBJ;

//接口定义
/***************************************************/

/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},
    {QTYPE_IMG, 74,TITLE_WIFI_Y,&alpha_title_lock, EXP_IMG_DEFT},

    {QTYPE_TXT, -109, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},

    {QTYPE_TXT, 0, 105, G_STR_BUF_TIME, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold83}}},

    {QTYPE_IMG, 0,0,&alpha_bg_grey, EXP_IMG_DEFT},
    {QTYPE_TXT, 0, 110, G_STR_BUF_REMIND, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold34}}},
    {QTYPE_IMG, 0,-20,&alpha_lock_off_big, EXP_IMG_DEFT},
    EXP_OBJ_END };


static void LabelRush(void)
{
    sprintf(G_STR_BUF_TITLE,"Home");
    
    sprintf(G_STR_BUF_TIME, "%02d:%02d", RunningState.time.cur.hour, RunningState.time.cur.min);
}

static void wifi_auto_show(void)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (RunningState.wifi_state)
    {
        case 0: //disconnect
            lqui.show_obj(PAGE1_OBJ_IMG_WIFI, 0);
            break;
        case 1: //connecting
            if (secold != g_main_sec)
            {
                secold = g_main_sec;
                twink_flag = !twink_flag;
                lqui.show_obj(PAGE1_OBJ_IMG_WIFI, twink_flag);
            }
            break;
        case 2: //complete
            lqui.show_obj(PAGE1_OBJ_IMG_WIFI, TRUE);
            break;
    }
}

static void lock_auto_show(void)
{
    if(RunningState.wifi_state)
        lqui.set_pos(PAGE1_OBJ_IMG_LOCK, 74, TITLE_WIFI_Y);
    else
        lqui.set_pos(PAGE1_OBJ_IMG_LOCK, TITLE_WIFI_X, TITLE_WIFI_Y);
}

static void PageMainLockShow(void)
{
    lqui.show_obj(PAGE1_OBJ_IMG_TOP, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TITLE, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TIME, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_REMIND, FALSE);
    lqui.show_obj(PAGE1_OBJ_LABEL_REMIND, FALSE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK_BIG, FALSE);
}

static void PageMainShow(void)
{
    lqui.show_obj(PAGE1_OBJ_IMG_TOP, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TIME, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TITLE, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK, FALSE);
    lqui.show_obj(PAGE1_OBJ_IMG_REMIND, FALSE);
    lqui.show_obj(PAGE1_OBJ_LABEL_REMIND, FALSE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK_BIG, FALSE);
}

static void PageSetLockRemindShow(void)
{
    lqui.show_obj(PAGE1_OBJ_IMG_TOP, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TIME, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TITLE, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_REMIND, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_REMIND, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK_BIG, FALSE);
    sprintf(G_STR_BUF_REMIND,"Hold\"CANCEL\"3s\nto UNLOCK");
    lqui.set_pos(PAGE1_OBJ_LABEL_REMIND, 0, 110);
}

static void PageSetUnlockShow(void)
{
    lqui.show_obj(PAGE1_OBJ_IMG_TOP, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TIME, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TITLE, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK, FALSE);
    lqui.show_obj(PAGE1_OBJ_IMG_REMIND, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_REMIND, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK_BIG, TRUE);
    lqui.set_img_src(PAGE1_OBJ_IMG_LOCK_BIG, &alpha_lock_off_big);
    sprintf(G_STR_BUF_REMIND,"UNLOCK");
    lqui.set_pos(PAGE1_OBJ_LABEL_REMIND, 0, 140);
}

static void PageMainLockOnRemindShow(void)
{
    lqui.show_obj(PAGE1_OBJ_IMG_TOP, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TIME, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_TITLE, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK, FALSE);
    lqui.show_obj(PAGE1_OBJ_IMG_REMIND, TRUE);
    lqui.show_obj(PAGE1_OBJ_LABEL_REMIND, TRUE);
    lqui.show_obj(PAGE1_OBJ_IMG_LOCK_BIG, TRUE);
    lqui.set_img_src(PAGE1_OBJ_IMG_LOCK_BIG, &alpha_lock_on_big);
    sprintf(G_STR_BUF_REMIND,"Lock");
    lqui.set_pos(PAGE1_OBJ_LABEL_REMIND, 0, 140);
}

static void page_run(void)
{
    if (RunningState.pageid == IdMainLock)
    {
        lock_auto_show();
        wifi_auto_show();
        LabelRush();
    }
    else if (RunningState.pageid == IdMain)
    {
        wifi_auto_show();
        LabelRush();
    }
    else if (RunningState.pageid == IdSetLockRemind)
    {
        wifi_auto_show();
        LabelRush();
        lock_auto_show();
    }
    else if (RunningState.pageid == IdSetUnlock)
    {
        wifi_auto_show();
        LabelRush();
    }
    else if (RunningState.pageid == IdMainLockOnRemind)
    {
        wifi_auto_show();
        LabelRush();
    }
}

void page_init_main_lock(void)
{
    //show or hide obj
    PageMainLockShow();
}

void page_init_main(void)
{
    //show or hide obj
    PageMainShow();
}

void page_init_sleep(void)
{
    //show or hide obj
    lqui.show_all(g_objs, FALSE);
}

void page_init_set_lock_remind(void)
{
    PageSetLockRemindShow();
}

void page_init_set_unlock(void)
{
    PageSetUnlockShow();
}

void page_init_main_lock_on_remind(void)
{
    PageMainLockOnRemindShow();
}

static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);
    static uint32_t flag_timesec = 0;
    ui_page_switch();
    page_run();
    
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
}


void screen_page1_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
