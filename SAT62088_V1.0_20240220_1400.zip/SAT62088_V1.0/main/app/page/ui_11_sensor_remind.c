﻿#include <stdio.h>
#include "screen_all.h"
#include "app/control/ctrl_main.h"
#include "app/lqui/lqui_helper.h"
#include "app/uikit/dev_pannel.h"
#include "app/page/global_value.h"

#define CUR_SCREEN_ID  PAGE11 // 当前页面的ID序号
static int g_obj_cnt = 0; // 当前页面的控件数量

#define G_STR_BUF_TITLE        g_strBuffer1
#define G_STR_BUF_DOWN         g_strBuffer2
#define G_STR_BUF_MIDDLE       g_strBuffer3

typedef enum {
    PAGE11_OBJ_IMG_TOP,
    PAGE11_OBJ_IMG_DOWN,
    PAGE11_OBJ_IMG_TITLE_WIFI,

    PAGE11_OBJ_LABEL_TITLE,
    PAGE11_OBJ_LABEL_DOWN,
    PAGE11_OBJ_LABEL_MIDDLE,

}SCREEN_PAGE11_OBJ;

//单独控件
/***************************************************/

/***************************************************/
//接口定义
/***************************************************/
static int cntsec = 0;
static bool g_remind = 0;//0-hid/1-show 5 sec
/***************************************************/


static QuiObj g_objs[] = {
    {QTYPE_IMG, BG_TOP_X,BG_TOP_Y,&alpha_bg_top, EXP_IMG_DEFT},
    {QTYPE_IMG, BG_DOWN_X,BG_DOWN_Y,&bg_down, EXP_IMG_DEFT},
    {QTYPE_IMG, TITLE_WIFI_X,TITLE_WIFI_Y,&alpha_title_wifi, EXP_IMG_DEFT},

    {QTYPE_TXT, -70, TITLE_LABEL_Y, G_STR_BUF_TITLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xD3D3D3,& myriadpro_semibold25}}},
    {QTYPE_TXT, 0, DOWN_LABEL_Y, G_STR_BUF_DOWN, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_regular25}}},
    {QTYPE_TXT, 0, 100, G_STR_BUF_MIDDLE, {LQ_OBJ_FLAG_CENTER,NULL,&(QuiTxtParam){0xFFFFFF,& myriadpro_semibold34}}},
    EXP_OBJ_END };


static void clean_remind(void)
{
    cntsec = g_main_sec;
}

static void remind_run(void)
{
    if (g_remind)
    {
        lqui.show_obj(PAGE11_OBJ_IMG_DOWN, TRUE);
        lqui.show_obj(PAGE11_OBJ_LABEL_DOWN, TRUE);

        if ((g_main_sec - cntsec) < 3)
            sprintf(G_STR_BUF_DOWN,"Press\"Start\"to cook");
        else if ((g_main_sec - cntsec) >= 6)
        {
            lqui.show_obj(PAGE11_OBJ_IMG_DOWN, FALSE);
            lqui.show_obj(PAGE11_OBJ_LABEL_DOWN, FALSE);
            g_remind = 0;
        }
        else
            sprintf(G_STR_BUF_DOWN,"Press\"Start\"to cook");
    }
    else
    {
        lqui.show_obj(PAGE11_OBJ_IMG_DOWN, FALSE);
        lqui.show_obj(PAGE11_OBJ_LABEL_DOWN, FALSE);
        clean_remind();
    }
}

static void wifi_auto_show(void)
{
    static int secold = 0;
    static bool twink_flag = 0;

    switch (RunningState.wifi_state)
    {
    case 0: //disconnect
        lqui.show_obj(PAGE11_OBJ_IMG_TITLE_WIFI, FALSE);
        break;
    case 1: //connecting
        if (secold != g_main_sec)
        {
            secold = g_main_sec;
            twink_flag = !twink_flag;
            lqui.show_obj(PAGE11_OBJ_IMG_TITLE_WIFI, twink_flag);
        }
        break;
    case 2: //complete
        lqui.show_obj(PAGE11_OBJ_IMG_TITLE_WIFI, TRUE);
        break;
    }
}

void page_init_sensor_reheat_add_food(void)
{
    ///show obj

    //set label and img
    sprintf(G_STR_BUF_TITLE,"Sensor Reheat");
    sprintf(G_STR_BUF_MIDDLE,"Please\nadd food.");
    //to do
    lqui.set_pos(PAGE11_OBJ_LABEL_TITLE, -70, TITLE_LABEL_Y);
    g_remind = TRUE;
    clean_remind();
}

static void screen_onHandle(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    screen_adjust_auto(&g_objs, g_obj_cnt, CUR_SCREEN_TAG);

    ui_page_switch();
    remind_run();
    wifi_auto_show();
}

static void screen_onQuit(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onQuit().", CUR_SCREEN_ID);
}

// init:value,pram,ui...
static void screen_onEnter(void* arg)
{
    PageParam* pgpm = (PageParam*)arg;
    println("#%02d# screen_onEnter().", CUR_SCREEN_ID);
    lqui.quiObjs = g_objs;
    lqui.objCount = g_obj_cnt;
    //TODO:
    clean_remind();
}

//////////////////////////////////////////////////////////////////////////


void screen_page11_init()
{
    lv_obj_t* parent_obj = lv_obj_create(NULL);
    LAYOUT_INIT(parent_obj, 0x000000);
}
