﻿#ifndef _CTRL_MAIN_H_
#define _CTRL_MAIN_H_

#define uint8_t unsigned char
#define uint16_t unsigned short
#define uint32_t unsigned int

// 常用数据结构Demo例子,与外设数据逻辑发生关联
// 理论上还可以将输入和输出的变量分成两个结构体,特殊情况下也可以合成一个结构体
// 如：AppParam app_out/app_set,app_in/app_get;



typedef struct Tag_AppParamIn
{
    uint8_t data_sn;    // 默认有数据变动自增，常用于判断是否需要更新界面
    uint8_t oper_cmd;   // 用户操作码或者命令，用于区分不同的操作动作
    uint16_t key_value; // 按键值
    uint16_t curr_temp; // 当前温度
    uint16_t set_temp;  // 设置温度
    uint8_t led_index;  // 需要设置哪个灯的位置
    uint8_t mode_level; // 如：舒适模式，静音模式，急速模式
    uint8_t user_level; // 如：热水器档位，风速档位等
} AppParamIn;


//一般带全屏幕IIC触摸的项目才需要用到此结构
typedef struct Tag_AppParamOut
{
    uint8_t beep_sn : 4;
    uint8_t beep_cnt : 4;
  //param cmd1
    uint8_t cmd1_menu;
    uint8_t cmd1_key_value;
    //param cmd2
    uint8_t cmd2_menu;
    uint8_t cmd2_bean_water_flag;
    uint8_t cmd2_coffee_strength;
    uint8_t cmd2_amount_low;
    uint8_t cmd2_amount_high;

} AppParamOut;


void ctrl_init();
void ctrl_main();

void clear_led_value();
void set_led_off(uint8_t led_id);
void set_led_on(uint8_t led_id);

extern AppParamIn app_in;
extern AppParamOut app_out;

#endif //!_CTRL_MAIN_H_
