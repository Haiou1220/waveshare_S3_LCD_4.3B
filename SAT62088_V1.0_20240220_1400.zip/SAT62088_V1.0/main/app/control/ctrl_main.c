﻿#include <stdio.h>
#include "ctrl_main.h"

#include <math.h>

//#include "app/page/global_value.h"

static uint16_t g_led_value = 0;

AppParamIn app_in;//app需要更新显示UI的参数
AppParamOut app_out;//app需要对外设控制的参数

void set_start_flag(uint8_t flag)
{
    
}

void get_key_value()
{

}

void get_temperature()
{
   // app_in.curr_temp = 10+rand()%38;
}

void light_set_out(uint8_t led_id,uint8_t bOn)
{
}

void light_all(uint8_t bOn)
{
}


void light_std_config()
{

}

void set_led_on(uint8_t led_id)
{
    g_led_value |= 1 << led_id;
}

void set_led_off(uint8_t led_id)
{
    g_led_value &= ~(1 << led_id);
}

void clear_led_value()
{
    g_led_value = 0;
}


void ctrl_init()
{

}

//mcu电控主循环函数
void ctrl_main()
{
  static int cnt = 0;
 // printf("ctrl_main,cnt=%d \n",cnt++);
  
  //process mcu periphera input

  
//process mcu periphera output


//process io logic  
  //printf("app: led_index = %d \n",app_in.led_index);
  //printf("app: curr_temp = %d \n",app_in.curr_temp);

}
