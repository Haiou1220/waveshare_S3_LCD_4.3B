﻿#ifndef __VIEW_H__
#define __VIEW_H__

void view_init();
void view_flush_window(QuiObj* page_objs);

#endif

