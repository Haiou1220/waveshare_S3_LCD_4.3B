﻿#include <stdio.h>
#include "lvgl.h"
#include "../lqui/lqui_base.h"
#include "../bps_driver/ringQueue.h"
#include "../bps_driver/mcu_platform.h"
#include "../page/screen_all.h"


#ifdef _WIN32
#include "app/bps_driver/pc_platform.h"
#else
//#include <pthread.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#endif // WIN32


TagRingQueue* g_ringQueue;

uint8_t g_page_id = PAGE1;//start screen set:0 || default = PAGE_MAIN
static int g_page_id_old = -1;
static uint8_t g_flag_flushScreen = 1;


void view_update()
{
    g_flag_flushScreen = 1;
}

void view_flush_window(QuiObj* page_objs)
{
    lqui_update_all_obj(page_objs);
    lqui_update_window();
}

void view_switch_page(uint8_t page_id)
{
    println("view_switch_page,new_page=%d/MAX=%d", page_id, MAX_SCREEN_ID);
    g_page_id = page_id;
    if (page_id >= MAX_SCREEN_ID)
    {
        println("\x1b[0;31m error: page[%d] is out of rang.\n\x1b[0m", page_id);
    }
}

static int view_func_loop(void* arg)
{
    void (*funcPt)(void* arg);
    short lenOut = 0;
    char* queueRecvPt = NULL;
    PageParam pgpm;
    QuiPage* pageObj_pt = NULL;

    g_ringQueue = ringQueue_init(10);
    if (g_ringQueue == NULL)
    {
        printf("error! g_ringQueue is null!\n");
        return -1;
    }

    /*
        uint8_t flag_quick_start = 0;
        get_var_u8(quick_start,&flag_quick_start);
        printf("flag_quick_start=%d.\n",flag_quick_start);
        if(flag_quick_start!=0)
        {
            g_page_id = PAGE_QSTART;
            flag_quick_start = 0;
            set_var_u8(quick_start,flag_quick_start);
            storage_sync_write();
        }
        else
            g_page_id = PAGE_MAIN;
            */

    printf("start view_func_loop().g_page_id=%d.\n", g_page_id);

    while (1)
    {
        lenOut = 0;
        pgpm.type = 0;
        queueRecvPt = ringQueue_pop(g_ringQueue, &lenOut);
        if (queueRecvPt != NULL)
        {
            //dump_hex("RingQueue:", queueRecvPt, lenOut);
            memcpy(&pgpm, queueRecvPt, lenOut);
            free(queueRecvPt - 1); // Raw first byte = Length
            g_page_id = pgpm.curr_page_id;
        }
        else
        {
            pgpm.curr_page_id = g_page_id;
            pgpm.last_page_id = g_page_id_old;
        }

        Sleep(10); // unit:ms
        //vTaskDelay(1);//ESP32
        if (g_page_id >= MAX_SCREEN_ID)
            continue;

        pgpm.curr_tick = GetTickCount();
        pageObj_pt = &g_all_screenObj[g_page_id];

#if 0 //msg for debug
        static int tick_last = 0;
        printf("[%lu] flush=%d,take=%ld ms.\n", pgpm.curr_tick, g_flag_flushScreen, pgpm.curr_tick - tick_last);
        tick_last = pgpm.curr_tick;
#endif

        if (g_page_id_old != g_page_id)
        {
            pgpm.last_page_id = g_page_id_old;
            println("[switch] new page=%d,old page=%d", g_page_id, g_page_id_old);
            if (g_page_id < MAX_SCREEN_ID)
            {
                if (g_page_id_old >= 0)
                {
                    funcPt = g_all_screenObj[g_page_id_old].page_quit_func;

                    if (funcPt != NULL)
                    {
                        // println("exit page(%d).", g_page_id_old);
                        (*funcPt)(&pgpm);
                        // lv_obj_clean(g_all_screenObj[g_page_id_old].parent);
                    }
                }
                funcPt = pageObj_pt->page_enter_func;
                if (funcPt != NULL)
                {
                    // println("init page(%d).",g_page_id);
                    (*funcPt)(&pgpm);
                    lv_scr_load(g_all_screenObj[g_page_id].parent);
                }
            }
            g_page_id_old = g_page_id;
            g_flag_flushScreen = 1;//flush when page is switching
        }
        // 当前页面的主循环
        funcPt = pageObj_pt->page_loop_func;
        if (funcPt != NULL)
        {
            (*funcPt)(&pgpm); // running looper
        }
        if (g_flag_flushScreen)
        {
            //g_flag_flushScreen = 0;//flush when user need!
            lqui_update_all_obj(pageObj_pt->page_objs);
            lqui_update_window();
        }
            RunningState.all_page_init_success_flag = 1;
    } //<< end while(1)
    return 0;
}

void view_init()
{
    start_thread(view_func_loop, 1024 * 3, 1);
}
