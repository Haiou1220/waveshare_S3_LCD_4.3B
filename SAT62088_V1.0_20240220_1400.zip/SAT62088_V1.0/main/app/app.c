﻿#include <stdio.h>
#include "app.h"


void app_init()
{
    println("app_init().");
    
    screen_all_init();
    view_init();
}
