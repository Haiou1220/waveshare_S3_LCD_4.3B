﻿#ifndef __LQUI_HELPER_H__
#define __LQUI_HELPER_H__

#include "lqui_base.h"

typedef struct TagLquiClass
{
    QuiObj *quiObjs;
    int objCount;
    void (*show_obj)(int obj_id, uint8_t bShow);
    void (*show_all)(QuiObj* objs, uint8_t bShow);
    void (*set_pos)(int obj_id, int x, int y);
    void (*set_img_src)(int obj_id, lv_img_dsc_t *src);
    void (*set_text)(int obj_id, char *str);
    void (*set_font)(int obj_id, lv_font_t* font);
    void (*set_color_param)(int obj_id, uint32_t color);    
    void (*set_line_pos)(int obj_id,int x0,int y0,int x1,int y1);    
    void (*obj_add_fag)(int obj_id,uint8_t qui_flag);
    void (*obj_clear_fag)(int obj_id,uint8_t qui_flag);
    void (*switch_page)(uint8_t page_id );
    lv_obj_t* (*get_main_obj)(int obj_id);
   
} LquiClass;

extern LquiClass lqui;
void lqui_helper_init();


#endif //!__LQUI_HELPER_H__
