﻿#ifndef __LQUI_BASE_H__
#define __LQUI_BASE_H__
//**************************************
// //  lqui version: V1.0
// //  modify time:2023-8-30
//*************************************
#include <stdio.h>
#define LQUI_VER "1.0"

#ifndef _WIN32
extern uint64_t GetTickCount();
#endif // !_WIN32

#define _S1 printf("[%d]_stop1_\n",GetTickCount())
#define _S2 printf("[%d]_stop2_\n",GetTickCount())
#define _S3 printf("[%d]_stop3_\n",GetTickCount())
#define _S4 printf("[%d]_stop4_\n",GetTickCount())
#define _S5 printf("[%d]_stop5_\n",GetTickCount())
#define _S6 printf("[%d]_stop6_\n",GetTickCount())
#define _S7 printf("[%d]_stop7_\n",GetTickCount())
#define _S8 printf("[%d]_stop8_\n",GetTickCount())



#define CANVAS_WIDTH  320//400 
#define CANVAS_HEIGHT 240//320

// #define uint8_t unsigned char
// #define uint16_t unsigned short
// #define uint32_t unsigned int


#define QUI_RED       (0XFF0000)//红色
#define QUI_GREEN     (0X00FF00)//绿色
#define QUI_BLUE      (0X0000FF)//蓝色
#define QUI_WHITE     (0XFFFFFF)//白色
#define QUI_BLACK     (0X000000)//黑色
#define QUI_YELLOW    (0XFFFF00)//黄色
#define QUI_CYAN      (0X00FFFF)//青色
#define QUI_MAGENTA   (0XFF00FF)//品红

#define QTYPE_IMG   0 //image
#define QTYPE_TXT   1 //text
#define QTYPE_BTN   2 //button
#define QTYPE_LNE   3 //line

#define LQ_OBJ_FLAG_HIDDEN 0X01
#define LQ_OBJ_FLAG_CENTER 0X02
#define LQ_OBJ_FLAG_COLOR  0X04
#define LQ_OBJ_FLAG_LEFT 0X08

//extram param default

#define EXP_IMG_DEFT {LQ_OBJ_FLAG_CENTER,NULL,&(QuiImgParam){0,0,0}}
#define EXP_TXT_DEFT {0x00,NULL,&(QuiTxtParam){0x00,NULL}}                        
#define EXP_BTN_DEFT {0x00,NULL,&(QuiBtnParam){"",0x00,NULL,NULL}}
#define EXP_LNE_DEFT {0x00,NULL,&(QuiLneParam){2,0x00}}
#define EXP_OBJ_END  {0xFF,0,0,NULL}



typedef struct Tag_QuiImgParam
{
   uint8_t enable_flag;
   uint8_t zoom;
   uint8_t angle;
} QuiImgParam;

typedef struct Tag_QuiTxtParam
{
    uint32_t nFontColor;
    lv_font_t* fontZiKu;
    
} QuiTxtParam;

typedef struct Tag_QuiBtnParam
{   //btn默认是图片作为主object
    char* str;
    uint32_t nFontColor;
    lv_font_t* fontZiKu;
    lv_obj_t* obj_txt;
} QuiBtnParam;

typedef struct Tag_QuiLneParam
{
  uint8_t lineWidth;  
  uint32_t lineColor;  
}QuiLneParam;

typedef struct Tag_LayoutParam
{
    uint8_t qui_flag;
    lv_obj_t* main_obj;
    void* extra_param;
} LayoutParam;


typedef struct
{
    int type;//0-image,1-textString,2-btn...
    int x;
    int y;
    void* dataSrc;//lv_img_dsc_t图像数据/或者字符串数值...
    LayoutParam layoutParam;

} QuiObj;



typedef struct
{
    int test;//test
    lv_obj_t* parent;
    QuiObj* page_objs;//界面上所有控件集合
    void (*page_quit_func)(void* arg);//页面退出时的函数
    void (*page_enter_func)(void* arg);//页面初始化指针函数
    void (*page_loop_func)(void* arg);//页面循环指针函数
    void (*page_callback_func)(void* arg);//页面回调响应
    
} QuiPage;



typedef struct Tag_PageParam
{
    uint32_t curr_tick;  
    uint8_t curr_page_id;
    uint8_t last_page_id;
    uint8_t type;//0:none,1:got_data
    uint8_t sn;//ui data was changed
} PageParam;

void lqui_update_window();
void lqui_init();
void lqui_center_screen(QuiObj* obj, uint8_t bFlagCenter);
void lqui_draw_obj(QuiObj obj);
int lqui_create_all_obj(QuiObj* pageObjs, lv_obj_t* parent);
int  lqui_update_all_obj(QuiObj* objs);
uint16_t lqui_rgb888_to_rgb565(uint32_t n888Color);
uint32_t lqui_rgb565_to_rgb888(uint16_t n565Color);

void lqui_get_resolution(uint16_t* width, uint16_t* height);
void lqui_show_obj(QuiObj* obj, uint8_t bShow);
void lqui_show_all(QuiObj* obj, uint8_t bShow);
void lqui_set_pos(QuiObj* obj, int x, int y);
void lqui_set_img_src(QuiObj* obj, lv_img_dsc_t* src);
void lqui_set_text(QuiObj *obj, char *str);
void lqui_set_font(QuiObj* obj, lv_font_t* font);
void lqui_set_color_param(QuiObj* obj, uint32_t color);
void lqui_set_line_pos(QuiObj *obj,int x0,int y0,int x1,int y1);
void lqui_obj_add_flag(QuiObj* obj, uint8_t qui_flag);
void lqui_obj_clear_flag(QuiObj* obj, uint8_t qui_flag);
lv_obj_t* lqui_get_main_obj(QuiObj* obj);


#ifdef _WIN32
void println(char* fmt, ...);
#else
//Log in [MCU]
#define println(format,...)  \
{   \
    printf("[%llu] (%s:%d):",GetTickCount(),__FUNCTION__, __LINE__); \
    printf(format,__VA_ARGS__); \
    printf("\n"); \
}
#endif

#endif //<<__LQUI_BASE_H__

