﻿#include "lvgl.h"
#include "lqui_base.h"
#include "stdlib.h"
#include "stdio.h"

#define RGB565_RED 0xf800
#define RGB565_GREEN 0x07e0
#define RGB565_BLUE 0x001f

#define RGB888_RED 0x00ff0000
#define RGB888_GREEN 0x0000ff00
#define RGB888_BLUE 0x000000ff

#if _WIN32
// Log in [WIN32]
#include "time.h"
void println(char *fmt, ...)
{
#define MAX_LOG_LENGTH (1024 * 2)
    char *buf = (char *)malloc(MAX_LOG_LENGTH); // 注意输出最大长度限制
    va_list args;
    va_start(args, fmt);
    vsprintf_s(buf, MAX_LOG_LENGTH, fmt, args);
    va_end(args);

    // 添加系统时间前缀
    time_t timep;
    struct tm *pt;
    char tmStr[28];
    time(&timep);
    pt = gmtime(&timep);
    sprintf(tmStr, "[%02d:%02d:%02d]", (pt->tm_hour + 8) % 24, pt->tm_min, pt->tm_sec);
    printf(tmStr);
    printf(buf); // 日志本体
    printf("\r\n");
    free(buf);
    return;
}
#endif

void lqui_get_resolution(uint16_t* width, uint16_t* height)
{
    *width = CANVAS_WIDTH;
    *height = CANVAS_HEIGHT;
}

void lqui_init()
{
    printf("LQUI_VER=%s.LCD:[%dx%d]\n", LQUI_VER,CANVAS_WIDTH,CANVAS_HEIGHT);
}

void lqui_update_window()
{
    // 请用户自己控制时序
    lv_task_handler(); // for lvgl fulsh screen
}

uint32_t lqui_rgb565_to_rgb888(uint16_t n565Color)
{
    uint32_t r = (n565Color & RGB565_RED) << 8;
    uint32_t g = (n565Color & RGB565_GREEN) << 5;
    uint32_t b = (n565Color & RGB565_BLUE) << 3;
    // 低位数据补偿
    if (n565Color != 0)
    {
        r |= 0x07 << 16;
        g |= 0x03 << 8;
        b |= 0x07;
    }
    return (r | g | b);
}

uint16_t lqui_rgb888_to_rgb565(uint32_t n888Color)
{
    // 获取RGB单色，并截取高位
    uint8_t r = (n888Color & RGB888_RED) >> 19;   // 5bit_R
    uint8_t g = (n888Color & RGB888_GREEN) >> 10; // 6bit_G
    uint8_t b = (n888Color & RGB888_BLUE) >> 3;   // 5bit_B

    return ((r << 11) | (g << 5) | (b << 0)); // r,g,b
}

void lqui_draw_btn(QuiObj obj)
{
    uint8_t type = obj.type;

    if (type != QTYPE_BTN)
        return;

    uint8_t qui_flag = obj.layoutParam.qui_flag;
    uint8_t bCenter = qui_flag & LQ_OBJ_FLAG_CENTER;
    QuiBtnParam *btnParm = (QuiBtnParam *)obj.layoutParam.extra_param;

    int x = obj.x;
    int y = obj.y;

    lv_obj_t *obj_img = obj.layoutParam.main_obj;
    lv_obj_t *obj_txt = btnParm->obj_txt;
    char *str = btnParm->str;
    lv_font_t *fontZiKu = btnParm->fontZiKu;
    uint32_t nFontColor = btnParm->nFontColor;
    lv_img_dsc_t *btn_gndImgSrc = (lv_img_dsc_t *)obj.dataSrc; // background image of button

    int img_wdh = 0;
    int img_hgt = 0;
    int pos_x = x;
    int pos_y = y;

    if (btn_gndImgSrc != NULL)
    {
        lv_img_set_src(obj_img, btn_gndImgSrc);
        lv_obj_set_pos(obj_img, x, y);
        img_wdh = btn_gndImgSrc->header.w;
        img_hgt = btn_gndImgSrc->header.h;
    }

    if (str != NULL )
    {
        lv_label_set_text(obj_txt, str);
        lv_obj_set_style_text_color(obj_txt, lv_color_hex(nFontColor), 0);

        if (fontZiKu)
            lv_obj_set_style_text_font(obj_txt, fontZiKu, 0);

        lv_obj_set_style_text_align(obj_txt, LV_TEXT_ALIGN_CENTER, 0);
        // lv_obj_set_style_align(obj_txt, LV_ALIGN_TOP_MID, 0);

        if (btn_gndImgSrc != NULL)
        {
            int txt_wdh = lv_obj_get_width(obj_txt);
            int txt_hgt = lv_obj_get_height(obj_txt);
            lv_obj_set_pos(obj_txt,(img_wdh-txt_wdh)/2,(img_hgt-txt_hgt)/2);
        }
    }
}

void lqui_draw_line(QuiObj obj)
{
    uint8_t type = obj.type;
    if (type != QTYPE_LNE)
        return;

    lv_obj_t *obj_main = obj.layoutParam.main_obj;
    uint8_t bCenter = (obj.layoutParam.qui_flag) & LQ_OBJ_FLAG_CENTER;
    QuiLneParam *qline = (QuiLneParam *)obj.layoutParam.extra_param;
    lv_obj_set_style_line_color(obj_main, lv_color_hex(qline->lineColor), 0);
    lv_obj_set_style_line_width(obj_main, qline->lineWidth, 0);
    lv_obj_set_style_line_rounded(obj_main, true, 0);
    lv_point_t *pt = (lv_point_t *)obj.dataSrc;
   
    if (bCenter)
    {
        println("raw x: %d,%d", pt[0].x, pt[1].x);

        int16_t line_len = pt[1].x - pt[0].x;
        if (line_len<0)
        {
            line_len = -line_len;
            pt[1].x = (CANVAS_WIDTH - line_len) / 2;
            pt[0].x = pt[1].x + line_len;//bigger posX
        }
        else
        {
            pt[0].x = (CANVAS_WIDTH - line_len) / 2;
            pt[1].x = pt[0].x + line_len;//bigger posX
        }
        println("out x: %d,%d,line_len=%d,WIDTH=%d", pt[0].x, pt[1].x,line_len,CANVAS_WIDTH);
        pt[0].x = 40;

    }
    lv_line_set_points(obj_main, pt, 2);
}

void lqui_draw_txt(QuiObj obj)
{
    uint8_t type = obj.type;
    if (type != QTYPE_TXT)
        return;

    lv_obj_t *lv_obj = obj.layoutParam.main_obj;
    QuiTxtParam *param = (QuiTxtParam *)obj.layoutParam.extra_param;
    uint32_t nFontColor = param->nFontColor;
    uint8_t qui_flag = obj.layoutParam.qui_flag;
    uint8_t bCenter = qui_flag;

    lv_font_t *fontZiKu = (lv_font_t *)param->fontZiKu;
    char *dispStr = (char *)obj.dataSrc;

    lv_obj_set_width(lv_obj, CANVAS_WIDTH);
    lv_label_set_text(lv_obj, dispStr);
    lv_obj_set_style_text_color(lv_obj, lv_color_hex(nFontColor), 0);
    lv_obj_set_pos(lv_obj,obj.x,obj.y);

    if (fontZiKu)
        lv_obj_set_style_text_font(lv_obj, fontZiKu, 0);

    if (bCenter & LQ_OBJ_FLAG_CENTER)
        lv_obj_set_style_text_align(lv_obj, LV_TEXT_ALIGN_CENTER, 0);
    else if(bCenter & LQ_OBJ_FLAG_LEFT)
        lv_obj_set_style_text_align(lv_obj, LV_TEXT_ALIGN_LEFT, 0);
}

void lqui_set_line_pos(QuiObj *obj, int x0, int y0, int x1, int y1)
{
    if (obj == NULL || obj->type != QTYPE_LNE)
        return;

    lv_point_t *pt = (lv_point_t *)obj->dataSrc;
    pt[0].x = x0;
    pt[0].y = y0;
    pt[1].x = x1;
    pt[1].y = y1;
    lv_line_set_points(obj->layoutParam.main_obj, pt, 2);
}

void lqui_draw_img(QuiObj obj)
{
    uint8_t type = obj.type;
    if (type != QTYPE_IMG)
        return;

    uint8_t bHideAble = (obj.layoutParam.qui_flag) & LQ_OBJ_FLAG_HIDDEN;
    uint8_t bCenter = (obj.layoutParam.qui_flag) & LQ_OBJ_FLAG_CENTER;
    lv_obj_t *main_obj = obj.layoutParam.main_obj;

    lv_img_dsc_t *dsc = (lv_img_dsc_t *)obj.dataSrc;
    lv_img_set_src(main_obj, dsc);
    if (bCenter)
    {
        lv_obj_set_style_align(main_obj, LV_ALIGN_CENTER, 0);
    }
    lv_obj_set_pos(main_obj, obj.x, obj.y);
}

void lqui_set_pos(QuiObj *obj, int x, int y)
{
    if (obj == NULL)
        return;

    obj->x = x;
    obj->y = y;
}

// 设置过滤色，或者字体颜色
void lqui_set_color_param(QuiObj *obj, uint32_t color)
{
    uint8_t type = -1;
    if (obj)
    {
        type = obj->type;
    }
    if (type == QTYPE_TXT)
    {
        QuiTxtParam *parm = obj->layoutParam.extra_param;
        parm->nFontColor = color;
    }
    else if (type == QTYPE_BTN)
    {
        QuiBtnParam *parm = obj->layoutParam.extra_param;
        parm->nFontColor = color;
    }
    else if (type == QTYPE_LNE)
    {
        QuiLneParam* parm = obj->layoutParam.extra_param;
        parm->lineColor = color;
    }
}

void lqui_set_font(QuiObj *obj, lv_font_t *font)
{
    uint8_t type = -1;
    if (obj)
    {
        type = obj->type;
    }
    if (type == QTYPE_TXT)
    {
        QuiTxtParam *parm = obj->layoutParam.extra_param;
        parm->fontZiKu = font;
    }
    else if (type == QTYPE_BTN)
    {
        QuiBtnParam *parm = obj->layoutParam.extra_param;
        parm->fontZiKu = font;
    }
}

void lqui_set_img_src(QuiObj *obj, lv_img_dsc_t *src)
{
    uint8_t type = -1;
    if (obj)
    {
        type = obj->type;
    }
    if (type == QTYPE_IMG || type == QTYPE_BTN)
    {
        obj->dataSrc = (void *)src;
    }
}

void lqui_set_text(QuiObj *obj, char *str)
{
    uint8_t type = -1;
    if (obj)
    {
        type = obj->type;
    }
    if (type == QTYPE_TXT)
    {
        obj->dataSrc = (void *)str;
    }
    else if (type == QTYPE_BTN)
    {
        QuiBtnParam *btnPm = (QuiBtnParam*)obj->layoutParam.extra_param;
        btnPm->str = str;
    }
}

lv_obj_t* lqui_get_main_obj(QuiObj* obj)
{
    if (!obj)
        return NULL;

    return obj->layoutParam.main_obj;

}

void lqui_show_obj(QuiObj *obj, uint8_t bShow)
{
    if (!obj)
        return;
    if (bShow)
    {
        // clear hide flag
        obj->layoutParam.qui_flag &= ~LQ_OBJ_FLAG_HIDDEN;
    }
    else
    {
        // set hide flag
        obj->layoutParam.qui_flag |= LQ_OBJ_FLAG_HIDDEN;
    }
}

void lqui_show_all(QuiObj* objs, uint8_t bShow)
{
    if (!objs)
        return;
    for (int i = 0;i < 0xff;i++)
    {
        if (objs[i].type == 0xFF)
        {
            break;
        }
        if (bShow)
        {
            // clear hide flag
            objs[i].layoutParam.qui_flag &= ~LQ_OBJ_FLAG_HIDDEN;
        }
        else
        {
            // set hide flag
            objs[i].layoutParam.qui_flag |= LQ_OBJ_FLAG_HIDDEN;
        }
    }
}

void lqui_center_scr(QuiObj *obj)
{
    if (!obj)
        return;

    lv_img_dsc_t *dsc = (lv_img_dsc_t *)obj->dataSrc;
    obj->x = (CANVAS_WIDTH - dsc->header.w) / 2;
    obj->y = (CANVAS_HEIGHT - dsc->header.h) / 2;
}

void lqui_center(QuiObj *obj, QuiObj gndObj)
{
    if (!obj)
        return;
    lv_img_dsc_t *dsc = (lv_img_dsc_t *)obj->dataSrc;
    lv_img_dsc_t *gnd = (lv_img_dsc_t *)gndObj.dataSrc;

    obj->x = (gnd->header.w - dsc->header.w) / 2;
    obj->y = (gnd->header.h - dsc->header.h) / 2;
}

void lqui_center_screen(QuiObj *obj, uint8_t bFlagCenter)
{
    if (!obj)
        return;
    // set bit2, center flag
    if (bFlagCenter)
    {
        obj->layoutParam.qui_flag |= LQ_OBJ_FLAG_CENTER;
    }
    else
    {
        obj->layoutParam.qui_flag &= ~LQ_OBJ_FLAG_CENTER;
    }
}

void lqui_obj_add_flag(QuiObj *obj, uint8_t flag)
{
    if (!obj)
        return;

    obj->layoutParam.qui_flag |= flag;
}

void lqui_obj_clear_flag(QuiObj *obj, uint8_t flag)
{
    obj->layoutParam.qui_flag &= ~flag;
}

void lqui_draw_obj(QuiObj obj)
{
    uint8_t bHideAble = (obj.layoutParam.qui_flag) & LQ_OBJ_FLAG_HIDDEN;
    uint8_t obj_type = obj.type;
    lv_obj_t *main_obj = obj.layoutParam.main_obj;

    if (bHideAble)
    {
        lv_obj_add_flag(main_obj, LV_OBJ_FLAG_HIDDEN);
        return;
    }
    else
    {
        lv_obj_clear_flag(main_obj, LV_OBJ_FLAG_HIDDEN);
    }

    if (obj_type == QTYPE_IMG)
    {
        lqui_draw_img(obj);
    }
    else if (obj_type == QTYPE_TXT)
    {
        lqui_draw_txt(obj);
    }
    else if (obj_type == QTYPE_BTN)
    {
        lqui_draw_btn(obj);
    }
    else if (obj_type == QTYPE_LNE)
    {
        lqui_draw_line(obj);
    }
    else
    {
        return; // no define obj type
    }
}

int lqui_create_all_obj(QuiObj *pageObjs, lv_obj_t *parent)
{
    int num = 0;
    uint8_t obj_type = 0xFF;

    for (size_t i = 0; i < 0xFF; i++)
    {
        obj_type = pageObjs[i].type;

        if (obj_type == 0xFF)
        {
            break;
        }
        num++;

        if (obj_type == QTYPE_IMG)
        {
            pageObjs[i].layoutParam.main_obj = lv_img_create(parent);
        }
        else if (obj_type == QTYPE_TXT)
        {
            pageObjs[i].layoutParam.main_obj = lv_label_create(parent);
        }
        else if (obj_type == QTYPE_BTN)
        {
            lv_obj_t *gndImgObj = lv_img_create(parent);
            pageObjs[i].layoutParam.main_obj = gndImgObj;
            QuiBtnParam *qbtn = pageObjs[i].layoutParam.extra_param;
            qbtn->obj_txt = lv_label_create(gndImgObj);
        }
        else if (obj_type == QTYPE_LNE)
        {
            lv_obj_t *obj = lv_line_create(parent);
            pageObjs[i].layoutParam.main_obj = obj;
            QuiLneParam *qline = (QuiLneParam *)pageObjs[i].layoutParam.extra_param;
            lv_obj_set_style_line_color(obj, lv_color_hex(qline->lineColor), 0);
            lv_obj_set_style_line_width(obj, qline->lineWidth, 0);
            lv_obj_set_style_line_rounded(obj, true, 0);
            lv_point_t *pt = (lv_point_t *)pageObjs[i].dataSrc;
            lv_line_set_points(obj, pt, 2);
        }
        // public setting
    }
    return num;
}

int lqui_update_all_obj(QuiObj *objs)
{
    int ret = 0;
    for (int i = 0; i < 0xFF; i++)
    {
        if (objs[i].type == 0xFF)
            break;
        lqui_draw_obj(objs[i]);
        ret++;
    }
    return ret;
  
}
