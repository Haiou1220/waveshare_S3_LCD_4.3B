﻿#include <stdint.h>
#include "lvgl.h"
#include "lqui_base.h"
#include "lqui_helper.h"

extern void view_switch_page(uint8_t page_id);
LquiClass lqui;


void __lqui_show_all(QuiObj* objs, uint8_t bShow)
{
    lqui_show_all(objs, bShow);
}

void __lqui_show_obj(int obj_id, uint8_t bShow)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }
    lqui_show_obj(&lqui.quiObjs[obj_id], bShow);
}

void __lqui_set_pos(int obj_id, int x, int y)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }
    lqui_set_pos(&lqui.quiObjs[obj_id], x, y);
}

void __lqui_set_img_src(int obj_id, lv_img_dsc_t *src)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }
    lqui_set_img_src(&lqui.quiObjs[obj_id], src);
}

void __lqui_set_color_param(int obj_id, uint32_t color)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }
    lqui_set_color_param(&lqui.quiObjs[obj_id], color);
}

void __lqui_set_line_pos(int obj_id,int x0,int y0,int x1,int y1)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }    
    lqui_set_line_pos(&lqui.quiObjs[obj_id],x0,y0,x1,y1);
}

void __lqui_set_font(int obj_id, lv_font_t* font)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }    
    lqui_set_font(&lqui.quiObjs[obj_id],font);
}

void __lqui_obj_add_flag(int obj_id, uint8_t qui_flag)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }        
    lqui_obj_add_flag(&lqui.quiObjs[obj_id],qui_flag);
}

void __lqui_obj_clear_flag(int obj_id, uint8_t qui_flag)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }        
    lqui_obj_clear_flag(&lqui.quiObjs[obj_id],qui_flag);    
}

void __lqui_set_text(int obj_id, char *str)
{
    if (obj_id >= lqui.objCount)
    {
        return;
    }  
    lqui_set_text(&lqui.quiObjs[obj_id], str);      
}

lv_obj_t* __lqui_get_main_obj(int obj_id)
{
    if (obj_id >= lqui.objCount)
    {
        return NULL;
    }
   return lqui_get_main_obj(&lqui.quiObjs[obj_id]);
}


/******************************************
 *
 *
 *******************************************/
void lqui_helper_init()
{
    lqui.show_obj = __lqui_show_obj;
    lqui.show_all = __lqui_show_all;
    lqui.set_pos = __lqui_set_pos;
    lqui.set_img_src = __lqui_set_img_src;
    lqui.set_font = __lqui_set_font;
    lqui.set_color_param = __lqui_set_color_param;
    lqui.set_line_pos = __lqui_set_line_pos;
    lqui.obj_add_fag = __lqui_obj_add_flag;
    lqui.obj_clear_fag = __lqui_obj_clear_flag;
    lqui.switch_page = view_switch_page;
    lqui.set_text = __lqui_set_text;
    lqui.get_main_obj = __lqui_get_main_obj;

    lqui_init();
}
