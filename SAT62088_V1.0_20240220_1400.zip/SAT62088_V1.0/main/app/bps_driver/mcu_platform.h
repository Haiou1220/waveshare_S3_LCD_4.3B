#ifndef __MCU_PLATFORM_H__
#define __MCU_PLATFORM_H__

void Sleep(int ms);
uint64_t GetTickCount();
void start_thread(int(*func)(void* arg), int stackSize, int uxPriority);
#endif