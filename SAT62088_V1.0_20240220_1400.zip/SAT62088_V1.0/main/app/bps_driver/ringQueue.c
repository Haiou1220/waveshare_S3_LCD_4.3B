﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ringQueue.h"
 

static void dump_hex(char* infoStr, char* buf, int len)
{
    printf("%s(%d)", infoStr, len);
    for (int i = 0;i < len;i++)
    {
        printf("%02X ", (unsigned char)buf[i]);
    }
    printf("\n");
}


 
TagRingQueue* ringQueue_init(int size)
{
	 //Note: (size-1) is full!!
	TagRingQueue * rb;
    rb = (TagRingQueue*)malloc(sizeof(TagRingQueue));
    if( rb == NULL)
    {
        return NULL;
    }
    rb->buffer = (char**)malloc( size* sizeof(char**) );
    if( rb->buffer == NULL )
    {
        return 0;
    }
 
	rb->maxCount = size;
	rb->wrPos = 0;
	rb->rdPos = 0;
	rb->remainCnt = 0;
    return rb;
}
 
void ringQueue_free(TagRingQueue* rb)
{
	if( rb )
	{
		if(rb-> buffer)
		{
			free( rb-> buffer );
		}
		free( rb );
	}
}
 
int is_ringQueue_full(TagRingQueue* rb)
{
  //Note:(MAXCOUNT-1) is full!!
	if( ( (rb->wrPos)+1)%(rb->maxCount) == rb->rdPos )
	 return 1;
 
    return 0;
}
 
int is_ringQueue_empty(TagRingQueue* rb)
{
	if( (rb->wrPos) == rb->rdPos ){
	 return 1;
	}
 
    return 0;
}
 
//注意:data第一字节存数据长度,后面的数据才是本体 
//注意使用完后必须释放指针.
char* ringQueue_pop(TagRingQueue* rb,short *lenOut)
{  //read
    char *buff_pt = NULL;
	*lenOut = 0;
	if( is_ringQueue_empty(rb))
	{
		return NULL;
	}


	buff_pt = (char*)rb->buffer[ rb->rdPos ];
    
	rb->rdPos =  (rb->rdPos +1)%rb->maxCount;
	rb->remainCnt --;
   
	if( buff_pt != NULL)
	{
		*lenOut = *buff_pt;//first byte => Length
		buff_pt++;
	}	
	return buff_pt;//must free after use! NOTE: free(buff_pt-1);
}
 
//注意:data第一字节存数据长度,后面的数据才是本体
int ringQueue_push(TagRingQueue* rb,char *data,short len)
{  //write
    char *buff_pt = NULL;
	if( is_ringQueue_full(rb))
	{
		return 0;
	}
	buff_pt = (char*)malloc(len+1);
	if( buff_pt == NULL )
	{
		return -1;//no mem
	}
	buff_pt[0] = len; //data第一字节存数据长度
	memcpy(buff_pt+1,data,len);
	rb->buffer[ rb->wrPos ] = buff_pt;
	rb->wrPos =  (rb->wrPos +1)%(rb->maxCount);
	rb->remainCnt++;
	return 1;
}
 
int ringQueue_getRemainCnt(TagRingQueue* rb)
{
	return rb->remainCnt;
}
 
