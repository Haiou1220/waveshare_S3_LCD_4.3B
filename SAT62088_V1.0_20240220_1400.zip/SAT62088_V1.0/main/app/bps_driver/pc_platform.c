﻿#ifdef _WIN32

#include "windows.h"

//pthread_t thread_view;
//pthread_create(&thread_view, NULL, view_func_loop, NULL);

void start_thread(int(*func)(void* arg), int stackSize, int uxPriority)
{
    HANDLE handle = CreateThread(NULL, 0, func, NULL, 0, NULL);
    CloseHandle(handle);
}

void* my_malloc(size_t size)
{
    return malloc(size);
}

// return -1 when no key press,triggle by rise pulse
int get_curr_key()
{
#define max_touch_key 13
    extern unsigned char g_touchKey[max_touch_key];
    extern unsigned char g_touchKeyOld[max_touch_key];
    int ret_value = -1;
    for (size_t i = 0; i < max_touch_key; i++)
    {
        if (g_touchKeyOld[i] != g_touchKey[i])
        {
            g_touchKeyOld[i] = g_touchKey[i];
            if (g_touchKey[i])
            {
                ret_value = i;
            }
        }
    }
    return ret_value;
}

unsigned char g_longKeyCnt[max_touch_key];

//ret=0 no key press, 1 short press, 2 long press
void get_key_result(int *ret,int *key_value)
{
#define max_touch_key 13
    extern unsigned char g_longKey[max_touch_key];
    extern unsigned char g_touchKey[max_touch_key];
    extern unsigned char g_touchKeyOld[max_touch_key];
    int flag_ret = 0;
    int key_ret = -1;
    const int long_press_length = 20;//N*60ms
     
    for (size_t i = 0; i < max_touch_key; i++)
    {
        if (g_longKey[i] >= long_press_length)
        {
            if (++g_longKeyCnt[i] > 10)  //when long press ,continue output
            {
                g_longKeyCnt[i] = 0;
                key_ret = i;
                flag_ret = 2;//long press
            }
            else
            {
                key_ret = -1;
                flag_ret = 0;//None press!
            }
            break;
        }
        else if (g_longKey[i] > 0 )
        {
            if (g_touchKeyOld[i]!= g_touchKey[i])
            {
                    g_longKeyCnt[i] = 0;
                    g_longKey[i] = 0;
                    key_ret = i;
                    flag_ret = 1;//short press
                    //KEY释放的时输出ture
            }
            else
            {
                key_ret = -1;
                flag_ret = 0;//None press!
            }
            break;
        }
    }

    for (size_t i = 0; i < max_touch_key; i++)
    {
        if (g_touchKey[i])
        {
            if (++g_longKey[i] > long_press_length)
                g_longKey[i] = long_press_length;
        }
        else
        {
            g_longKey[i] = 0;
            g_longKeyCnt[i] = 0;
        }
        g_touchKeyOld[i] = g_touchKey[i];
    }

    *ret = flag_ret;
    *key_value = key_ret;
    
}

void reset_key_result()
{
#define max_touch_key 13
    extern unsigned char g_longKey[max_touch_key];
    extern unsigned char g_touchKey[max_touch_key];
    extern unsigned char g_touchKeyOld[max_touch_key];
    for (size_t i = 0; i < max_touch_key; i++)
    {
        g_longKey[i] = 0;
        g_longKeyCnt[i] = 0;
        g_touchKeyOld[i] = g_touchKey[i];               
    }
}

void increase_beep_cnt()
{

}

#endif // !_WIN32


