﻿#ifndef __RING_QUEUE_H__
#define __RING_QUEUE_H__

typedef struct TAG_RING_QUEUE
{
    int wrPos;
    int rdPos;
    int maxCount;
    int remainCnt;
    char** buffer;//storage address

} TagRingQueue;

#ifdef __cplusplus
extern "C" {
#endif

    TagRingQueue* ringQueue_init(int size);
    void ringQueue_free(TagRingQueue* rb);
    char* ringQueue_pop(TagRingQueue* rb, short* lenOut);
    int ringQueue_push(TagRingQueue* rb, char* data, short len);
    int ringQueue_getRemainCnt(TagRingQueue* rb);

#ifdef __cplusplus
}
#endif


#endif // !__RING_QUEUE_H__


