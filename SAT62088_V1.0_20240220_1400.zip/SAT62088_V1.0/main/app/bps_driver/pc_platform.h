﻿//#define StartThread(thrFun) CloseHandle(CreateThread(NULL, 0, thrFun, NULL, 0, NULL))
void start_thread(int(*func)(void* arg), int stackSize, int uxPriority);
void* my_malloc(size_t size);
int get_curr_key();

