﻿#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "mcu_platform.h"

void Sleep(int ms)
{
    vTaskDelay(pdMS_TO_TICKS(ms));
}

uint64_t GetTickCount()
{
    return esp_log_timestamp();
}

void start_thread(int(*func)(void* arg), int stackSize, int uxPriority)
{
    char task_name[10] = { 0 };
    static int task_index = 0;
    sprintf(task_name, "task%u", ++task_index);
    xTaskCreate(func, task_name, stackSize, NULL, uxPriority, NULL);
}

void* my_malloc(size_t size)
{
    //return malloc(size);
    return heap_caps_malloc(size, MALLOC_CAP_DMA);
}
