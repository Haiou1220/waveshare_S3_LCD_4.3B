﻿#ifndef __APP_H__
#define __APP_H__
#include "mcu_platform.h"

#ifdef _WIN32
//C++宏定义print
#define println(format,...)  \
{   \
    printf("[%llu] (%s:%d):",GetTickCount(),__FUNCTION__, __LINE__); \
    printf(format,__VA_ARGS__); \
    printf("\n"); \
}
#else
//C宏定义print
#define println(format, args...)  \
{   \
    printf("[%llu] (%s:%d):",GetTickCount(),__FUNCTION__, __LINE__); \
    printf(format,##args); \
    printf("\n"); \
}
#endif

extern void view_init();
extern void screen_all_init();

void app_init();

#endif
