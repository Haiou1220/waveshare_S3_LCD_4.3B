#ifndef _DRIVER_PROTOCOL_H_
#define _DRIVER_PROTOCOL_H_

#include "stdio.h"
#include "string.h"
#include "stdbool.h"

#define UART_RXBUF_SIZE    (UART_RX_MAX+UART_RX_MAX)    

typedef enum
{
    UART_RX_HANDER = 0,
    UART_RX_LEN,
    UART_RX_PAGEID,
    UART_RX_WARING1,
    UART_RX_WARING2,
    UART_RX_SET_TEMP_H,
    UART_RX_SET_TEMP_L,
    UART_RX_CUR_TEMP_H,
    UART_RX_CUR_TEMP_L,
    UART_RX_WORK_HOUR,
    UART_RX_WORK_MIN,
    UART_RX_WORK_SEC,
    UART_RX_POWER,
    UART_RX_WEIGHT_H,
    UART_RX_WEIGHT_L,
    UART_RX_ERROR,
    UART_RX_STEAM_LEVEL,
    UART_RX_CUR_HOUR,
    UART_RX_CUR_MIN,
    UART_RX_CUR_SEC,
    UART_RX_CUR_WEEKEND,
    UART_RX_NEXT_TEMP_H,
    UART_RX_NEXT_TEMP_L,
    UART_RX_CONTROL_VERSION,
    UART_RX_SCREEN_VERSION,
    UART_RX_WORK_HOUR_NEXT,
    UART_RX_WORK_MIN_NEXT,
    UART_RX_WORK_SEC_NEXT,
    UART_RX_WIFI_STATE,
    UART_RX_MENU_INDEX,
    UART_RX_CHECKSUM,

    UART_RX_MAX,
} UART_RX_ENUM;





struct uart_ringbuffer
{
    uint8_t *buffer_ptr;  
    uint8_t read_mirror;  
    uint16_t read_index;  
    uint8_t write_mirror; 
    uint16_t write_index; 
    uint16_t buffer_size; 
};




void uart_DataAnalysis(void);
uint8_t uart_ringbuffer_putchar(const uint8_t ch);
void uart_ringbuffer_init(void);
void Uart_SendInt(void);
bool get_g_factory_uart_ok(void);
void UART_SendInt(void);

#endif