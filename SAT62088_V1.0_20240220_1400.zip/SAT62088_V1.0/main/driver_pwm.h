#ifndef _DRIVER_PWM_H_
#define _DRIVER_PWM_H_

#include <stdio.h>
#include "driver/ledc.h"
#include "esp_err.h"
#include "screen_all.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "freertos/queue.h"

void pwm_init(void);
void bl_run(void);

#endif