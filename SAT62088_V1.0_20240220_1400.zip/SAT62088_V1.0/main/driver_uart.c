#include "driver_uart.h"
#include "driver_protocol.h"
#include "screen_all.h"

#define TAG "RS485_ECHO_APP"
// Note: Some pins on target chip cannot be assigned for UART communication.
// Please refer to documentation for selected board and target to configure pins using Kconfig.
#define UART_TEST_TXD 19//18
#define UART_TEST_RXD 18//19

// RTS for RS485 Half-Duplex Mode manages DE/~RE
#define UART_TEST_RTS (UART_PIN_NO_CHANGE)

// CTS is not used in RS485 Half-Duplex Mode
#define UART_TEST_CTS (UART_PIN_NO_CHANGE)

#define URAT_SIZE (127)
#define BAUD_RATE (19200)

// Read packet timeout
#define PACKET_READ_TICS (100 / portTICK_PERIOD_MS)
#define UART_TASK_STACK_SIZE (1024*5)
#define UART_TASK_PRIO (10)

// Timeout threshold for UART = number of symbols (~10 tics) with unchanged state on receive pin
#define UART_READ_TOUT (3) // 3.5T * 8 = 28 ticks, TOUT=3 -> ~24..33 ticks

uint8_t g_page3_finish_flag = 1;
uint8_t g_touch_wake_up_flag = 1;
int g_touch_wake_up_tick = 0;
// An example of echo test with hardware flow control on UART
static void uart_task(void *arg)
{
    const int uart_num = BYD_UART_PORT;
    uart_config_t uart_config = {
        .baud_rate = BAUD_RATE,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 122,
        .source_clk = UART_SCLK_DEFAULT,
    };

    // Set UART log level
    esp_log_level_set(TAG, ESP_LOG_INFO);

    ESP_LOGI(TAG, "Start RS485 application test and configure UART.");

    // Install UART driver (we don't need an event queue here)
    // In this example we don't even use a buffer for sending data.
    ESP_ERROR_CHECK(uart_driver_install(uart_num, URAT_SIZE * 2, 0, 0, NULL, 0));

    // Configure UART parameters
    ESP_ERROR_CHECK(uart_param_config(uart_num, &uart_config));

    ESP_LOGI(TAG, "UART set pins, mode and install driver.");

    // Set UART pins as per KConfig settings
    ESP_ERROR_CHECK(uart_set_pin(uart_num, UART_TEST_TXD, UART_TEST_RXD, UART_TEST_RTS, UART_TEST_CTS));

    // Set read timeout of UART TOUT feature
    ESP_ERROR_CHECK(uart_set_rx_timeout(uart_num, UART_READ_TOUT));

    // Allocate buffers for UART
    uint8_t *data = (uint8_t *)malloc(URAT_SIZE);

    uart_ringbuffer_init();
    

    while (1)
    {
        if(get_g_factory_flag())
            UART_SendInt();

        #if SYSTEM_DEBUG
            extern int8_t g_main_sec;

            static int sec_old = 0;
            if(RunningState.all_page_init_success_flag == 1)
            {
                if(sec_old != g_main_sec)
                {
                    sec_old = g_main_sec;
                    if(RunningState.pageid < (IdMax-1))
                        RunningState.pageid++;
                    else
                        RunningState.pageid = 0;

                    printf("debug id==>%d\n",RunningState.pageid);
                }
            }
            else
                sec_old = g_main_sec;
            vTaskDelay(pdMS_TO_TICKS(50));
        #else
        int len = uart_read_bytes(uart_num, data, 31, PACKET_READ_TICS);

        if (len > 0)
        {
            for(int i=0;i<len;i++)
            {
                uart_ringbuffer_putchar(data[i]);
            }
        }
        else
        {
        }
        uart_DataAnalysis();

        vTaskDelay(5);
        #endif
    }
    vTaskDelete(NULL);
}

void uart_init(void)
{
    xTaskCreate(uart_task, "uart_task", UART_TASK_STACK_SIZE, NULL, UART_TASK_PRIO, NULL);
}
