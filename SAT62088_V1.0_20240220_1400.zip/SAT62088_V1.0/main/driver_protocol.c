#include "driver_protocol.h"
#include "driver_uart.h"
#include "esp_log.h"
#include "screen_all.h"

static uint8_t gBUartSBuf[UART_RX_MAX + UART_RX_MAX] = {0}; // 实际发送数据缓冲器
static uint8_t uart_rx_buf[UART_RXBUF_SIZE] = {0};
struct uart_ringbuffer R_uart_rb; /* 定义一个 ringbuffer cb */
static bool g_factory_uart_ok = 0;

void uart_ringbuffer_init(void)
{
    R_uart_rb.read_mirror = R_uart_rb.read_index = 0;
    R_uart_rb.write_mirror = R_uart_rb.write_index = 0;

    R_uart_rb.buffer_ptr = uart_rx_buf;
    R_uart_rb.buffer_size = UART_RXBUF_SIZE;
}

uint8_t uart_ringbuffer_data_len() // 数据长度
{
    if (R_uart_rb.read_index == R_uart_rb.write_index)
    {
        if (R_uart_rb.read_mirror == R_uart_rb.write_mirror)
            return 0;
        else
            return R_uart_rb.buffer_size;
    }
    else if (R_uart_rb.write_index > R_uart_rb.read_index)
        return R_uart_rb.write_index - R_uart_rb.read_index;
    else
        return R_uart_rb.buffer_size - (R_uart_rb.read_index - R_uart_rb.write_index);
}

uint8_t uart_ringbuffer_putchar(const uint8_t ch)
{
    if (!(R_uart_rb.buffer_size - uart_ringbuffer_data_len()))
        return 0;
    R_uart_rb.buffer_ptr[R_uart_rb.write_index] = ch;
    if (R_uart_rb.write_index == R_uart_rb.buffer_size - 1)
    {
        R_uart_rb.write_mirror = ~R_uart_rb.write_mirror;
        R_uart_rb.write_index = 0;
    }
    else
        R_uart_rb.write_index++;
    return 1;
}
uint8_t uart_ringbuffer_getchar(uint8_t *ch)
{
    if (!uart_ringbuffer_data_len())
        return 0;

    /* put character */
    *ch = R_uart_rb.buffer_ptr[R_uart_rb.read_index];
    if (R_uart_rb.read_index == R_uart_rb.buffer_size - 1)
    {
        R_uart_rb.read_mirror = ~R_uart_rb.read_mirror;
        R_uart_rb.read_index = 0;
    }
    else
        R_uart_rb.read_index++;
    return 1;
}

static int data_check(uint8_t *buf,uint8_t len)
{
    uint8_t checksum = 0;

    for(int i = 1;i<len-1;i++)
    {
        checksum += buf[i];
    }
    checksum = (0x100 - checksum);

    if(checksum == buf[len-1])
        return 1;
    else
        return -1;
}

void UART_SendInt(void)
{
    uint8_t wr_data[UART_RX_MAX] = {0};
    uint8_t checksum = 0;

    wr_data[0] = 0xaa;
    wr_data[1] = 0x11;
    wr_data[2] = 0x22;
    wr_data[3] = 0x33;
    wr_data[4] = 0x44;
    wr_data[5] = 0x55;
    wr_data[6] = 0x66;
    wr_data[7] = 0x77;
    wr_data[8] = 0x88;
    wr_data[9] = 0x99;
    wr_data[10] = 0x00;
    wr_data[11] = 0x11;
    wr_data[12] = 0x22;
    wr_data[13] = 0x33;
    wr_data[14] = 0x44;
    wr_data[15] = 0x55;
    wr_data[16] = 0x66;
    wr_data[17] = 0x77;
    wr_data[18] = 0x88;
    wr_data[19] = 0x99;
    wr_data[20] = 0x00;
    wr_data[21] = 0x11;
    wr_data[22] = 0x22;
    wr_data[23] = 0x33;
    wr_data[24] = 0x44;
    wr_data[25] = 0x55;
    wr_data[26] = 0x66;
    wr_data[27] = 0x77;
    wr_data[28] = 0x88;
    wr_data[29] = 0x99;

    for(int i = 1;i<30;i++)
    {
        checksum += wr_data[i];
    }
    checksum = (0x100 - checksum);

    wr_data[30] = checksum;

    uart_write_bytes(1,wr_data,UART_RX_MAX);
}

bool get_g_factory_uart_ok(void)
{
    return g_factory_uart_ok;
}


static void recv_to_do(uint8_t *buf,uint8_t len)
{
    const uint8_t factory_data[UART_RX_MAX-1] = {0xaa,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99};
    uint8_t fct_cnt = 0;

    if(get_g_factory_flag())//g_factory_uart_ok
    {
        for(int i=0;i<UART_RX_MAX-1;i++)
        {
            if(buf[i] == factory_data[i])
                fct_cnt++;
        }
        if(fct_cnt == UART_RX_MAX-1)
        {
            g_factory_uart_ok = 1;
            fct_cnt = 0;
        }
        else
        {
            g_factory_uart_ok = 0;
            fct_cnt = 0;
        }
    }
    else
    {
        RunningState.pageid = buf[UART_RX_PAGEID];
        RunningState.remind1 = buf[UART_RX_WARING1];
        RunningState.remind2 = buf[UART_RX_WARING2];
        RunningState.temp.set = ((buf[UART_RX_SET_TEMP_H]<<8) | buf[UART_RX_SET_TEMP_L]);
        RunningState.temp.cur = ((buf[UART_RX_CUR_TEMP_H]<<8) | buf[UART_RX_CUR_TEMP_L]);
        RunningState.temp.next = ((buf[UART_RX_NEXT_TEMP_H]<<8) | buf[UART_RX_NEXT_TEMP_L]);
        RunningState.time.cur.hour = buf[UART_RX_CUR_HOUR];
        RunningState.time.cur.min = buf[UART_RX_CUR_MIN];
        RunningState.time.cur.sec = buf[UART_RX_CUR_SEC];
        RunningState.time.next.hour = buf[UART_RX_WORK_HOUR_NEXT];
        RunningState.time.next.min = buf[UART_RX_WORK_MIN_NEXT];
        RunningState.time.next.sec = buf[UART_RX_WORK_SEC_NEXT];
        RunningState.time.set.hour = buf[UART_RX_WORK_HOUR];
        RunningState.time.set.min = buf[UART_RX_WORK_MIN];
        RunningState.time.set.sec = buf[UART_RX_WORK_SEC];
        RunningState.version.control = buf[UART_RX_CONTROL_VERSION];
        RunningState.version.screen = buf[UART_RX_SCREEN_VERSION];
        RunningState.weekday = buf[UART_RX_CUR_WEEKEND];
        RunningState.power = buf[UART_RX_POWER];
        RunningState.weight = ((buf[UART_RX_WEIGHT_H]<<8) | buf[UART_RX_WEIGHT_L]);
        RunningState.error = buf[UART_RX_ERROR];
        RunningState.steam_level = buf[UART_RX_STEAM_LEVEL];
        RunningState.wifi_state = buf[UART_RX_WIFI_STATE];
        RunningState.menu_index = buf[UART_RX_MENU_INDEX];
    }
    

}


void uart_DataAnalysis(void)
{
    static uint8_t R_buf[UART_RX_MAX + UART_RX_MAX] = {0};
    static uint8_t R_index = 0;

    while ((uart_ringbuffer_getchar(R_buf + R_index) == 1))
    {
        switch (R_index)
        {
        case 0:
            if (R_buf[0] == 0xAA)
            {
                R_index++;
            }
            break;
        case 1:
            if(R_buf[1] == 0xAA)
            {
            }
            else
                R_index++;
            break;
        default:
            R_index++;
            if (R_index == UART_RX_MAX)
            {
                if (data_check(R_buf, R_index))
                {
                    #if SYSTEM_DEBUG
                    #else
                    printf("recv ok!copy running state\n");
                    recv_to_do(R_buf,R_index);
                    #endif
                }
                R_index = 0;
            }
            break;
        }
    }
}
