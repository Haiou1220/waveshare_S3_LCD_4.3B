#include "../../lv_examples.h"
#if LV_USE_SJPG && LV_BUILD_EXAMPLES

/**
 * Load an SJPG image
 */
void lv_example_sjpg_1(void)
{

    LV_IMG_DECLARE(img_wink_jpg);
    lv_obj_t * img;

    img = lv_img_create(lv_scr_act());
    lv_img_set_src(img, &img_wink_jpg);
    lv_obj_align(img, LV_ALIGN_LEFT_MID, 20, 0);
    
    // lv_obj_t * wp;

    // wp = lv_img_create(lv_scr_act());
    // /* Assuming a File system is attached to letter 'A'
    //  * E.g. set LV_USE_FS_STDIO 'A' in lv_conf.h */
    // lv_img_set_src(wp, "A:lvgl/examples/libs/sjpg/small_image.sjpg");
}

#endif
